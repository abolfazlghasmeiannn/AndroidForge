<?php
/**
 * PalfinFlix Android API Gateway
 * Place this file next to palfintvapk.php on the server.
 * Android app calls: https://YOUR-DOMAIN/.../palfin_android_api.php?action=...
 *
 * Reuses the same JSON files and PHP endpoints as the web mini-app.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Palfin-Token, X-Chat-Id');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

$BASE_DIR = __DIR__;

function j_ok($data = []) {
  echo json_encode(array_merge(['ok' => true], $data), JSON_UNESCAPED_UNICODE);
  exit;
}
function j_err($msg, $code = 400) {
  http_response_code($code);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}
function body_json() {
  $d = json_decode(file_get_contents('php://input'), true);
  return is_array($d) ? $d : [];
}
function proxy_get($url) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 20,
    CURLOPT_USERAGENT => 'PalfinAndroid/1.0',
  ]);
  $data = curl_exec($ch);
  $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return [$status, $data];
}
function proxy_post_json($url, $payload) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT => 20,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_USERAGENT => 'PalfinAndroid/1.0',
  ]);
  $data = curl_exec($ch);
  $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return [$status, $data];
}
function absolute_url($relative) {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  $scheme = $https ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
  return $scheme . '://' . $host . $dir . '/' . ltrim($relative, '/');
}

$action = isset($_GET['action']) ? (string)$_GET['action'] : '';
$body = ($_SERVER['REQUEST_METHOD'] === 'POST') ? body_json() : [];
if ($action === '' && isset($body['action'])) $action = (string)$body['action'];

// ---------- config: endpoints Android should use ----------
if ($action === 'config' || $action === '') {
  j_ok([
    'app' => 'PalfinFlix',
    'version' => 1,
    'theme' => 'netflix-dark',
    'endpoints' => [
      'settings'   => absolute_url('palfin_android_api.php?action=settings'),
      'tmdb'       => absolute_url('palfin_android_api.php?action=tmdb'),
      'tmdb_img'   => absolute_url('palfintvapk.php?tmdb_img=1'),
      'auth'       => absolute_url('palfin_auth.php'),
      'comments'   => absolute_url('palfin_comments.php'),
      'ratings'    => absolute_url('palfin_ratings.php'),
      'requests'   => absolute_url('palfin_requests.php'),
      'latest'     => absolute_url('fetch_latest_uploads.php'),
      'download'   => 'https://palfin.ir/PalfinFlix/select_file/index.php',
      'payment'    => 'https://codexia.ir/payment/request.php',
      'support'    => 'https://t.me/palfinflixsupport',
      'bot'        => 'https://t.me/palfinflixbot',
    ],
    'auth_flow' => [
      'create'  => 'POST palfin_auth.php?action=create  {user_agent}',
      'status'  => 'GET  palfin_auth.php?action=status&pin=XXXXXX',
      'confirm' => 'POST palfin_auth.php?action=confirm {pin,chat_id,name,photo_url}',
      'devices' => 'GET  palfin_auth.php?action=devices&chat_id=',
      'revoke'  => 'POST palfin_auth.php?action=revoke  {chat_id,token}',
      'validate'=> 'GET  palfin_auth.php?action=validate&token=',
    ],
    'notes' => 'Same server files as web mini-app. Admin edits via palfinadmin.php update palfin_settings.json.',
  ]);
}

// ---------- settings (same file as web) ----------
if ($action === 'settings') {
  $file = $BASE_DIR . '/palfin_settings.json';
  $default = [
    'logoUrl' => '',
    'heroImdbIds' => ['tt0111161','tt0068646','tt0468569','tt0137523','tt0109830'],
    'heroBackdropByImdb' => new stdClass(),
    'nav' => [
      'home' => ['label' => 'خانه', 'icon' => ''],
      'latest' => ['label' => 'جدیدترین‌ها', 'icon' => ''],
      'share' => ['label' => 'اشتراک', 'icon' => ''],
      'anim' => ['label' => 'انیمیشن', 'icon' => ''],
      'suggest' => ['label' => 'پیشنهاد', 'icon' => ''],
    ],
    'subscription' => [
      'logoUrl' => '',
      'buttonUrl' => '',
      'buttonText' => '',
      'descText' => 'با خرید اشتراک دسترسی به فیلم ها برات فراهم میشه و با خیال راحت فیلم و سریالت تماشا کن',
      'mainTitle' => 'اشتراک ویژه پالفین‌فلیکس',
      'plans' => [
        ['id' => 1, 'label' => '30 روزه', 'price' => 49000, 'oldPrice' => 79000],
        ['id' => 2, 'label' => '90 روزه', 'price' => 129000, 'oldPrice' => 199000],
        ['id' => 3, 'label' => '180 روزه', 'price' => 219000, 'oldPrice' => 349000],
        ['id' => 4, 'label' => '365 روزه', 'price' => 349000, 'oldPrice' => 599000],
      ],
    ],
    'supportUrl' => 'https://t.me/palfinflixsupport',
    'updatedAt' => 0,
  ];
  if (is_file($file)) {
    $raw = @file_get_contents($file);
    $data = json_decode($raw, true);
    if (is_array($data)) {
      $default = array_replace_recursive($default, $data);
    }
  }
  j_ok(['settings' => $default]);
}

// ---------- TMDB proxy (same as palfintvapk.php?tmdb_api=1) ----------
if ($action === 'tmdb') {
  $path = isset($_GET['path']) ? (string)$_GET['path'] : (string)($body['path'] ?? '');
  if (!preg_match('#^/[a-zA-Z0-9_\-/]+$#', $path)) {
    j_err('bad path', 400);
  }
  $params = $_GET;
  unset($params['action'], $params['path'], $params['tmdb_api']);
  // Always force safe defaults
  if (!isset($params['api_key'])) {
    // Same key used by web app (server-side only — not exposed as separate secret in app binary if you prefer)
    $params['api_key'] = '8e817bd885c70f2eff5e9a2af54be473';
  }
  if (!isset($params['language'])) $params['language'] = 'fa-IR';
  if (!isset($params['include_adult'])) $params['include_adult'] = 'false';

  $remoteUrl = 'https://api.themoviedb.org/3' . $path . '?' . http_build_query($params);
  list($status, $data) = proxy_get($remoteUrl);
  http_response_code($status ?: 500);
  header('Content-Type: application/json; charset=utf-8');
  echo ($data !== false && $data !== null) ? $data : '{}';
  exit;
}

// ---------- forward helpers to existing PHP modules ----------
if ($action === 'auth') {
  // Forward query + body to palfin_auth.php
  $sub = isset($_GET['sub']) ? (string)$_GET['sub'] : (string)($body['sub'] ?? ($body['action'] ?? 'status'));
  $q = $_GET;
  unset($q['action']);
  $q['action'] = $sub;
  $url = $BASE_DIR . '/palfin_auth.php';
  if (!is_file($url)) j_err('palfin_auth.php missing', 500);
  // Internal include-style via HTTP loopback is cleaner for existing scripts
  $target = absolute_url('palfin_auth.php') . '?' . http_build_query($q);
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    list($status, $data) = proxy_post_json($target, $body);
  } else {
    list($status, $data) = proxy_get($target);
  }
  http_response_code($status ?: 500);
  echo ($data !== false) ? $data : '{"ok":false}';
  exit;
}

if ($action === 'comments' || $action === 'ratings' || $action === 'requests') {
  $map = [
    'comments' => 'palfin_comments.php',
    'ratings'  => 'palfin_ratings.php',
    'requests' => 'palfin_requests.php',
  ];
  $file = $map[$action];
  if (!is_file($BASE_DIR . '/' . $file)) j_err($file . ' missing', 500);
  $q = $_GET;
  unset($q['action']);
  $target = absolute_url($file);
  if (!empty($q)) $target .= '?' . http_build_query($q);
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    list($status, $data) = proxy_post_json($target, $body);
  } else {
    list($status, $data) = proxy_get($target);
  }
  http_response_code($status ?: 500);
  echo ($data !== false) ? $data : '{"ok":false}';
  exit;
}

if ($action === 'latest') {
  $file = is_file($BASE_DIR . '/fetch_latest_uploads.php')
    ? 'fetch_latest_uploads.php'
    : (is_file($BASE_DIR . '/latest_Uploads.php') ? 'latest_Uploads.php' : '');
  if ($file === '') j_err('latest uploads script missing', 404);
  list($status, $data) = proxy_get(absolute_url($file));
  http_response_code($status ?: 500);
  echo ($data !== false) ? $data : '{}';
  exit;
}

// ---------- download URL builder (app opens this in browser/webview) ----------
if ($action === 'download_url') {
  $imdb = preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['imdb_id'] ?? ($body['imdb_id'] ?? '')));
  $chat = preg_replace('/[^0-9\-]/', '', (string)($_GET['chat_id'] ?? ($body['chat_id'] ?? '')));
  if ($imdb === '' || strpos($imdb, 'tt') !== 0) j_err('bad_imdb');
  if ($chat === '' || $chat === '123') j_err('need_chat_id', 403);
  $url = 'https://palfin.ir/PalfinFlix/select_file/index.php?chat_id=' . rawurlencode($chat)
    . '&imdb_id=' . rawurlencode($imdb) . '&from_app=1';
  j_ok(['url' => $url]);
}

j_err('unknown_action', 400);
