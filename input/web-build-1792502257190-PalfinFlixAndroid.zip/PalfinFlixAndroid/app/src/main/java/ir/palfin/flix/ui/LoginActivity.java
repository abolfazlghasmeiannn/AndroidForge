package ir.palfin.flix.ui;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

import ir.palfin.flix.PalfinApp;
import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.AuthCreateResponse;
import ir.palfin.flix.model.AuthStatusResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private TextView txtPin, txtStatus;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String pin;
    private boolean done;
    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (done || pin == null) return;
            ApiClient.api().authStatus("status", pin).enqueue(new Callback<AuthStatusResponse>() {
                @Override
                public void onResponse(Call<AuthStatusResponse> call, Response<AuthStatusResponse> response) {
                    AuthStatusResponse body = response.body();
                    if (body == null || !body.ok) {
                        if (body != null && ("expired".equals(body.error) || "not_found".equals(body.error))) {
                            txtStatus.setText("کد منقضی شد؛ دوباره تلاش کنید");
                            return;
                        }
                        handler.postDelayed(poll, 1400);
                        return;
                    }
                    if ("approved".equals(body.status) && body.token != null) {
                        if (done) return;
                        done = true;
                        String chat = body.user != null ? body.user.chat_id : "";
                        String name = body.user != null ? body.user.name : "کاربر";
                        String photo = body.user != null ? body.user.photo_url : "";
                        PalfinApp.get().session().save(body.token, chat, name, photo);
                        txtStatus.setText("با موفقیت وارد شدید");
                        Toast.makeText(LoginActivity.this, "با موفقیت وارد شدید", Toast.LENGTH_SHORT).show();
                        finish();
                        return;
                    }
                    handler.postDelayed(poll, 1400);
                }
                @Override
                public void onFailure(Call<AuthStatusResponse> call, Throwable t) {
                    handler.postDelayed(poll, 1800);
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtPin = findViewById(R.id.txtPin);
        txtStatus = findViewById(R.id.txtStatus);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        createPin();
    }

    private void createPin() {
        Map<String, String> body = new HashMap<>();
        body.put("action", "create");
        body.put("user_agent", "PalfinFlix-Android");
        ApiClient.api().authCreate("create", body).enqueue(new Callback<AuthCreateResponse>() {
            @Override
            public void onResponse(Call<AuthCreateResponse> call, Response<AuthCreateResponse> response) {
                AuthCreateResponse b = response.body();
                if (b == null || !b.ok || b.pin == null) {
                    txtStatus.setText("خطا در ساخت کد");
                    return;
                }
                pin = b.pin;
                txtPin.setText(pin);
                txtStatus.setText("در انتظار تأیید از مینی‌اپ...");
                handler.postDelayed(poll, 1200);
            }
            @Override
            public void onFailure(Call<AuthCreateResponse> call, Throwable t) {
                txtStatus.setText("خطای شبکه / palfin_auth.php");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        done = true;
        handler.removeCallbacks(poll);
    }
}
