package ir.palfin.flix.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbListResponse;
import ir.palfin.flix.model.TmdbMovie;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private LinearLayout sections;
    private SwipeRefreshLayout swipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sections = findViewById(R.id.sectionsContainer);
        swipe = findViewById(R.id.swipe);
        swipe.setColorSchemeResources(R.color.red);
        swipe.setOnRefreshListener(this::loadHome);

        BottomNavigationView nav = findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_search) {
                startActivity(new Intent(this, SearchActivity.class));
                return true;
            }
            if (id == R.id.nav_account) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return true;
        });

        findViewById(R.id.toolbar).setOnLongClickListener(v -> {
            startActivity(new Intent(this, SearchActivity.class));
            return true;
        });

        loadHome();
    }

    private void loadHome() {
        swipe.setRefreshing(true);
        sections.removeAllViews();
        loadRow("محبوب‌ترین‌ها", "/movie/popular", new HashMap<>());
        Map<String, String> action = new HashMap<>();
        action.put("with_genres", "28");
        action.put("sort_by", "popularity.desc");
        loadRow("اکشن", "/discover/movie", action);
        Map<String, String> adv = new HashMap<>();
        adv.put("with_genres", "12");
        adv.put("sort_by", "popularity.desc");
        loadRow("ماجراجویی", "/discover/movie", adv);
        loadRow("سریال‌های محبوب", "/tv/popular", new HashMap<>());
        swipe.setRefreshing(false);
    }

    private void loadRow(String title, String path, Map<String, String> params) {
        ApiClient.api().tmdbList("tmdb", path, params).enqueue(new Callback<TmdbListResponse>() {
            @Override
            public void onResponse(Call<TmdbListResponse> call, Response<TmdbListResponse> response) {
                if (!response.isSuccessful() || response.body() == null || response.body().results == null) {
                    return;
                }
                addSection(title, response.body().results);
            }
            @Override
            public void onFailure(Call<TmdbListResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, R.string.error_network, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addSection(String title, List<TmdbMovie> list) {
        LinearLayout block = (LinearLayout) LayoutInflater.from(this)
                .inflate(R.layout.item_section, sections, false);
        TextView t = block.findViewById(R.id.txtSectionTitle);
        t.setText("▌ " + title);
        RecyclerView rv = block.findViewById(R.id.rvRow);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        PosterAdapter adapter = new PosterAdapter(m -> {
            Intent i = new Intent(MainActivity.this, DetailActivity.class);
            i.putExtra("type", m.type());
            i.putExtra("id", m.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);
        adapter.submit(list);
        sections.addView(block);
    }
}
