package ir.palfin.flix.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class TmdbMovie {
    public int id;
    public String title;
    public String name;
    @SerializedName("original_title") public String originalTitle;
    @SerializedName("original_name") public String originalName;
    public String overview;
    @SerializedName("poster_path") public String posterPath;
    @SerializedName("backdrop_path") public String backdropPath;
    @SerializedName("release_date") public String releaseDate;
    @SerializedName("first_air_date") public String firstAirDate;
    @SerializedName("vote_average") public double voteAverage;
    @SerializedName("vote_count") public int voteCount;
    @SerializedName("media_type") public String mediaType;
    public List<Genre> genres;
    @SerializedName("production_countries") public List<Country> productionCountries;
    @SerializedName("imdb_id") public String imdbId;
    public boolean adult;

    public static class Genre {
        public int id;
        public String name;
    }
    public static class Country {
        @SerializedName("iso_3166_1") public String iso;
        public String name;
    }

    public String displayTitle() {
        if (title != null && !title.isEmpty()) return title;
        if (name != null && !name.isEmpty()) return name;
        return "—";
    }

    public String year() {
        String d = releaseDate != null ? releaseDate : firstAirDate;
        if (d != null && d.length() >= 4) return d.substring(0, 4);
        return "";
    }

    public String type() {
        if ("tv".equalsIgnoreCase(mediaType) || (name != null && title == null)) return "tv";
        return "movie";
    }
}
