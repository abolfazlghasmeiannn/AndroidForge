package ir.palfin.flix.model;

import com.google.gson.JsonObject;

public class SettingsResponse {
    public boolean ok;
    public JsonObject settings;
}
