package ir.palfin.flix.api;

import com.google.gson.JsonObject;

import java.util.Map;

import ir.palfin.flix.model.AuthCreateResponse;
import ir.palfin.flix.model.AuthStatusResponse;
import ir.palfin.flix.model.ConfigResponse;
import ir.palfin.flix.model.SettingsResponse;
import ir.palfin.flix.model.TmdbListResponse;
import ir.palfin.flix.model.TmdbMovie;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface PalfinApi {

    @GET("palfin_android_api.php")
    Call<ConfigResponse> config(@Query("action") String action);

    @GET("palfin_android_api.php")
    Call<SettingsResponse> settings(@Query("action") String action);

    /** TMDB via server proxy — path like /movie/popular */
    @GET("palfin_android_api.php")
    Call<TmdbListResponse> tmdbList(
            @Query("action") String action,
            @Query("path") String path,
            @QueryMap Map<String, String> params
    );

    @GET("palfin_android_api.php")
    Call<TmdbMovie> tmdbDetail(
            @Query("action") String action,
            @Query("path") String path,
            @QueryMap Map<String, String> params
    );

    @GET("palfin_android_api.php")
    Call<JsonObject> tmdbRaw(
            @Query("action") String action,
            @Query("path") String path,
            @QueryMap Map<String, String> params
    );

    // Auth uses existing palfin_auth.php (same as web)
    @POST("palfin_auth.php")
    Call<AuthCreateResponse> authCreate(@Query("action") String action, @Body Map<String, String> body);

    @GET("palfin_auth.php")
    Call<AuthStatusResponse> authStatus(@Query("action") String action, @Query("pin") String pin);

    @POST("palfin_auth.php")
    Call<AuthStatusResponse> authConfirm(@Query("action") String action, @Body Map<String, String> body);

    @GET("palfin_auth.php")
    Call<JsonObject> authValidate(@Query("action") String action, @Query("token") String token);
}
