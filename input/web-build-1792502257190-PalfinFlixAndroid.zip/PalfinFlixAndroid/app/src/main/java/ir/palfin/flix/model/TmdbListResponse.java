package ir.palfin.flix.model;

import java.util.List;

public class TmdbListResponse {
    public int page;
    public List<TmdbMovie> results;
    @com.google.gson.annotations.SerializedName("total_pages") public int totalPages;
}
