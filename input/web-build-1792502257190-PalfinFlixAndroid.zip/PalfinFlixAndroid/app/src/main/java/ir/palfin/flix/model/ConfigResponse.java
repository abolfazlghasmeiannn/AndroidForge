package ir.palfin.flix.model;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class ConfigResponse {
    public boolean ok;
    public String app;
    public int version;
    public Map<String, String> endpoints;
}
