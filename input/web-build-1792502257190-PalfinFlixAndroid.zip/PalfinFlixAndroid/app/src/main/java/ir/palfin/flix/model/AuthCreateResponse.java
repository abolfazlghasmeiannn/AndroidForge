package ir.palfin.flix.model;

public class AuthCreateResponse {
    public boolean ok;
    public String pin;
    public String error;
    public int ttl;
}
