package ir.palfin.flix.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbMovie;

public class PosterAdapter extends RecyclerView.Adapter<PosterAdapter.VH> {
    public interface Listener {
        void onClick(TmdbMovie m);
    }

    private final List<TmdbMovie> items = new ArrayList<>();
    private final Listener listener;

    public PosterAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<TmdbMovie> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_poster, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        TmdbMovie m = items.get(position);
        h.rating.setText(String.format(Locale.US, "★ %.1f", m.voteAverage));
        Glide.with(h.poster).load(ApiClient.posterUrl(m.posterPath)).into(h.poster);
        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(m);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView poster;
        TextView rating;
        VH(@NonNull View itemView) {
            super(itemView);
            poster = itemView.findViewById(R.id.imgPoster);
            rating = itemView.findViewById(R.id.txtRating);
        }
    }
}
