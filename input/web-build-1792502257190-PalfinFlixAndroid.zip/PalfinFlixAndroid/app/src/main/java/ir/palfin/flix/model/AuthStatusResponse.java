package ir.palfin.flix.model;

public class AuthStatusResponse {
    public boolean ok;
    public String status;
    public String token;
    public String error;
    public User user;

    public static class User {
        public String chat_id;
        public String name;
        public String photo_url;
    }
}
