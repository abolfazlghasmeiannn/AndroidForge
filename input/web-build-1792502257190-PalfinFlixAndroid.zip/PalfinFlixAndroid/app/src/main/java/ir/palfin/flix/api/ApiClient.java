package ir.palfin.flix.api;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class ApiClient {
    private static String baseUrl = "https://palfin.ir/palfinapk/";
    private static PalfinApi api;

    private ApiClient() {}

    public static void init(String base) {
        if (base != null && !base.isEmpty()) {
            baseUrl = base.endsWith("/") ? base : base + "/";
        }
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        api = retrofit.create(PalfinApi.class);
    }

    public static PalfinApi api() {
        if (api == null) init(baseUrl);
        return api;
    }

    public static String baseUrl() {
        return baseUrl;
    }

    /** TMDB image via existing palfintvapk.php proxy */
    public static String posterUrl(String path) {
        if (path == null || path.isEmpty()) return null;
        String file = path.startsWith("/") ? path.substring(1) : path;
        return baseUrl + "palfintvapk.php?tmdb_img=1&cat=posters&size=w342&path=" + file;
    }

    public static String backdropUrl(String path) {
        if (path == null || path.isEmpty()) return null;
        String file = path.startsWith("/") ? path.substring(1) : path;
        return baseUrl + "palfintvapk.php?tmdb_img=1&cat=backdrops&size=w1280&path=" + file;
    }
}
