package ir.palfin.flix;

import android.app.Application;

import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.data.SessionManager;

public class PalfinApp extends Application {
    private static PalfinApp instance;
    private SessionManager session;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        session = new SessionManager(this);
        ApiClient.init(BuildConfig.BASE_URL);
    }

    public static PalfinApp get() {
        return instance;
    }

    public SessionManager session() {
        return session;
    }
}
