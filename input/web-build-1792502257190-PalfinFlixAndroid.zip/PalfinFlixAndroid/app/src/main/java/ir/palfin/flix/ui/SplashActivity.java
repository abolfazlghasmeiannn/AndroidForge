package ir.palfin.flix.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.ConfigResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ApiClient.api().config("config").enqueue(new Callback<ConfigResponse>() {
            @Override
            public void onResponse(Call<ConfigResponse> call, Response<ConfigResponse> response) {
                goMain();
            }
            @Override
            public void onFailure(Call<ConfigResponse> call, Throwable t) {
                goMain();
            }
        });

        // safety timeout
        new Handler(Looper.getMainLooper()).postDelayed(this::goMain, 2500);
    }

    private boolean opened;
    private void goMain() {
        if (opened) return;
        opened = true;
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
