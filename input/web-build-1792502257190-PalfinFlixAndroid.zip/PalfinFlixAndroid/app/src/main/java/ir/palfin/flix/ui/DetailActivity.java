package ir.palfin.flix.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import ir.palfin.flix.PalfinApp;
import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbListResponse;
import ir.palfin.flix.model.TmdbMovie;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {
    private String type;
    private int id;
    private String imdbId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        type = getIntent().getStringExtra("type");
        if (type == null) type = "movie";
        id = getIntent().getIntExtra("id", 0);

        ImageButton back = findViewById(R.id.btnBack);
        back.setOnClickListener(v -> finish());

        MaterialButton dl = findViewById(R.id.btnDownload);
        dl.setOnClickListener(v -> onDownload());

        loadDetail();
        loadSimilar();
    }

    private void loadDetail() {
        Map<String, String> p = new HashMap<>();
        ApiClient.api().tmdbDetail("tmdb", "/" + type + "/" + id, p).enqueue(new Callback<TmdbMovie>() {
            @Override
            public void onResponse(Call<TmdbMovie> call, Response<TmdbMovie> response) {
                if (!response.isSuccessful() || response.body() == null) return;
                bind(response.body());
            }
            @Override
            public void onFailure(Call<TmdbMovie> call, Throwable t) {
                Toast.makeText(DetailActivity.this, R.string.error_network, Toast.LENGTH_SHORT).show();
            }
        });
        // external ids for imdb
        ApiClient.api().tmdbRaw("tmdb", "/" + type + "/" + id + "/external_ids", new HashMap<>())
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                        if (response.body() != null && response.body().has("imdb_id")
                                && !response.body().get("imdb_id").isJsonNull()) {
                            imdbId = response.body().get("imdb_id").getAsString();
                        }
                    }
                    @Override public void onFailure(Call<JsonObject> call, Throwable t) {}
                });
    }

    private void bind(TmdbMovie m) {
        TextView title = findViewById(R.id.txtTitle);
        TextView meta = findViewById(R.id.txtMeta);
        TextView overview = findViewById(R.id.txtOverview);
        ImageView poster = findViewById(R.id.imgPoster);
        ImageView backdrop = findViewById(R.id.imgBackdrop);

        title.setText(m.displayTitle());
        StringBuilder sb = new StringBuilder();
        if (m.genres != null && !m.genres.isEmpty()) {
            sb.append(m.genres.get(0).name);
            if (m.genres.size() > 1) sb.append(" · ").append(m.genres.get(1).name);
        } else sb.append("—");
        sb.append(" | ");
        if (m.productionCountries != null && !m.productionCountries.isEmpty()) {
            sb.append(m.productionCountries.get(0).iso);
        } else sb.append("—");
        sb.append(" | ★ ").append(String.format(Locale.US, "%.1f", m.voteAverage));
        meta.setText(sb.toString());
        overview.setText(m.overview != null && !m.overview.isEmpty() ? m.overview : "خلاصه‌ای موجود نیست.");

        Glide.with(this).load(ApiClient.posterUrl(m.posterPath)).into(poster);
        Glide.with(this).load(ApiClient.backdropUrl(m.backdropPath != null ? m.backdropPath : m.posterPath)).into(backdrop);

        if (m.imdbId != null && m.imdbId.startsWith("tt")) imdbId = m.imdbId;
    }

    private void loadSimilar() {
        RecyclerView rv = findViewById(R.id.rvSimilar);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        PosterAdapter adapter = new PosterAdapter(m -> {
            Intent i = new Intent(this, DetailActivity.class);
            i.putExtra("type", m.type());
            i.putExtra("id", m.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);

        ApiClient.api().tmdbList("tmdb", "/" + type + "/" + id + "/similar", new HashMap<>())
                .enqueue(new Callback<TmdbListResponse>() {
                    @Override
                    public void onResponse(Call<TmdbListResponse> call, Response<TmdbListResponse> response) {
                        if (response.body() != null) adapter.submit(response.body().results);
                    }
                    @Override public void onFailure(Call<TmdbListResponse> call, Throwable t) {}
                });
    }

    private void onDownload() {
        String chatId = PalfinApp.get().session().getChatId();
        if (chatId == null || chatId.isEmpty() || "123".equals(chatId)) {
            Toast.makeText(this, R.string.login_required, Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            return;
        }
        if (imdbId == null || !imdbId.startsWith("tt")) {
            Toast.makeText(this, "شناسه IMDb در دسترس نیست", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = "https://palfin.ir/PalfinFlix/select_file/index.php?chat_id="
                + Uri.encode(chatId) + "&imdb_id=" + Uri.encode(imdbId) + "&from_app=1";
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
}
