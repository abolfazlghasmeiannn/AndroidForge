# PalfinFlix Android (Java)

Native Android client for the same backend as `palfintvapk.php`.

## Server setup
1. Upload `palfin_android_api.php` next to `palfintvapk.php` (same folder as `palfin_auth.php`, `palfin_settings.json`, …).
2. Ensure these already exist on server (from web app):
   - palfintvapk.php
   - palfin_auth.php
   - palfin_comments.php
   - palfin_ratings.php
   - palfin_requests.php
   - palfinadmin.php + palfin_settings.json
   - fetch_latest_uploads.php (optional)

## App setup
1. Open folder `PalfinFlixAndroid` in Android Studio.
2. In `app/build.gradle` set `BASE_URL` to your folder, e.g.:
   `https://palfin.ir/palfinapk/`
3. Sync Gradle → Run on device/emulator.

## Features in this MVP
- Home rows (popular / action / adventure / TV)
- Detail page + similar
- Search
- Login with 6-digit PIN (same `palfin_auth.php` as web)
- Download gated by login (same select_file URL)

## Next steps (same APIs)
- Comments / ratings / requests / subscription / hero slider from settings
