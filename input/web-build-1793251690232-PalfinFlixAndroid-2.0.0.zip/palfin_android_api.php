<?php
/**
 * PalfinFlix Android API — same folder as palfintvapk.php / palfinadmin.php
 * BASE: https://palfin.ir/palfinapk/palfin_android_api.php
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Palfin-Token, X-Chat-Id');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$BASE = __DIR__;
$TMDB_KEY = '8e817bd885c70f2eff5e9a2af54be473';

function j_ok($d = []) { echo json_encode(array_merge(['ok' => true], $d), JSON_UNESCAPED_UNICODE); exit; }
function j_err($m, $c = 400) { http_response_code($c); echo json_encode(['ok' => false, 'error' => $m], JSON_UNESCAPED_UNICODE); exit; }
function body_json() { $d = json_decode(file_get_contents('php://input'), true); return is_array($d) ? $d : []; }
function abs_url($rel) {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  $host = $_SERVER['HTTP_HOST'] ?? 'palfin.ir';
  $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
  return ($https ? 'https' : 'http') . '://' . $host . $dir . '/' . ltrim($rel, '/');
}
function curl_get($url) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 20, CURLOPT_USERAGENT => 'PalfinAndroid/2.0']);
  $data = curl_exec($ch); $st = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  return [$st, $data];
}
function curl_post($url, $payload) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 20, CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE), CURLOPT_USERAGENT => 'PalfinAndroid/2.0']);
  $data = curl_exec($ch); $st = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  return [$st, $data];
}

$action = (string)($_GET['action'] ?? '');
$body = $_SERVER['REQUEST_METHOD'] === 'POST' ? body_json() : [];
if ($action === '' && isset($body['action'])) $action = (string)$body['action'];

$DEFAULT = [
  'logoUrl' => '',
  'heroImdbIds' => ['tt0111161','tt0068646','tt0468569','tt0137523','tt0109830'],
  'heroBackdropByImdb' => new stdClass(),
  'nav' => [
    'home' => ['label'=>'خانه','icon'=>''],
    'latest' => ['label'=>'جدیدترین‌ها','icon'=>''],
    'share' => ['label'=>'اشتراک','icon'=>''],
    'anim' => ['label'=>'انیمیشن','icon'=>''],
    'suggest' => ['label'=>'پیشنهاد','icon'=>''],
  ],
  'subscription' => [
    'logoUrl' => '', 'buttonUrl' => '', 'buttonText' => '',
    'descText' => 'با خرید اشتراک دسترسی به فیلم ها برات فراهم میشه و با خیال راحت فیلم و سریالت تماشا کن',
    'mainTitle' => 'اشتراک ویژه پالفین‌فلیکس',
    'plans' => [
      ['id'=>1,'label'=>'30 روزه','price'=>49000,'oldPrice'=>79000],
      ['id'=>2,'label'=>'90 روزه','price'=>129000,'oldPrice'=>199000],
      ['id'=>3,'label'=>'180 روزه','price'=>219000,'oldPrice'=>349000],
      ['id'=>4,'label'=>'365 روزه','price'=>349000,'oldPrice'=>599000],
    ],
  ],
  'supportUrl' => 'https://t.me/palfinflixsupport',
  'updatedAt' => 0,
];

function read_settings($file, $default) {
  if (is_file($file)) {
    $data = json_decode(@file_get_contents($file), true);
    if (is_array($data)) return array_replace_recursive($default, $data);
  }
  return $default;
}

if ($action === 'config' || $action === '') {
  j_ok([
    'app' => 'PalfinFlix',
    'min_version' => '2.0.0',
    'features' => ['hero','genres','detail','search','auth_pin','download','subscription','settings'],
  ]);
}

if ($action === 'settings') {
  // Prefer same file written by palfinadmin.php
  $s = read_settings($BASE . '/palfin_settings.json', $DEFAULT);
  j_ok(['settings' => $s]);
}

if ($action === 'tmdb') {
  $path = (string)($_GET['path'] ?? ($body['path'] ?? ''));
  if (!preg_match('#^/[a-zA-Z0-9_\-/]+$#', $path)) j_err('bad path');
  $params = $_GET;
  unset($params['action'], $params['path']);
  if (empty($params['api_key'])) $params['api_key'] = $TMDB_KEY;
  if (!isset($params['language'])) $params['language'] = 'fa-IR';
  if (!isset($params['include_adult'])) $params['include_adult'] = 'false';
  // Prefer existing web proxy so cache/behavior matches mini-app
  $proxy = abs_url('palfintvapk.php') . '?tmdb_api=1&path=' . rawurlencode($path) . '&' . http_build_query($params);
  list($st, $data) = curl_get($proxy);
  if ($st < 200 || $st >= 300 || $data === false) {
    $remote = 'https://api.themoviedb.org/3' . $path . '?' . http_build_query($params);
    list($st, $data) = curl_get($remote);
  }
  http_response_code($st ?: 500);
  echo ($data !== false) ? $data : '{}';
  exit;
}

if ($action === 'img') {
  // Build cached image URL (same as web tmdb_img) — client loads this URL in ImageView only (not shown as text)
  $cat = (string)($_GET['cat'] ?? 'posters');
  $size = (string)($_GET['size'] ?? 'w342');
  $path = (string)($_GET['path'] ?? '');
  $file = basename($path);
  if ($file === '') j_err('bad path');
  j_ok(['url_path' => 'palfintvapk.php?tmdb_img=1&cat=' . rawurlencode($cat) . '&size=' . rawurlencode($size) . '&path=' . rawurlencode($file)]);
}

if ($action === 'download_url') {
  $imdb = preg_replace('/[^a-zA-Z0-9]/', '', (string)($_GET['imdb_id'] ?? ($body['imdb_id'] ?? '')));
  $chat = preg_replace('/[^0-9\-]/', '', (string)($_GET['chat_id'] ?? ($body['chat_id'] ?? '')));
  if ($imdb === '' || strpos($imdb, 'tt') !== 0) j_err('bad_imdb');
  if ($chat === '' || $chat === '123') j_err('need_chat_id', 403);
  // Do not echo bare domain in verbose form — still needed for Intent; app must not display it
  $url = 'https://palfin.ir/PalfinFlix/select_file/index.php?chat_id=' . rawurlencode($chat) . '&imdb_id=' . rawurlencode($imdb) . '&from_app=1';
  j_ok(['url' => $url]);
}

if ($action === 'auth') {
  $sub = (string)($_GET['sub'] ?? ($body['sub'] ?? ($body['action'] ?? 'status')));
  $q = $_GET; unset($q['action'], $q['sub']); $q['action'] = $sub;
  $target = abs_url('palfin_auth.php') . '?' . http_build_query($q);
  if ($_SERVER['REQUEST_METHOD'] === 'POST') list($st, $data) = curl_post($target, $body);
  else list($st, $data) = curl_get($target);
  http_response_code($st ?: 500);
  echo ($data !== false) ? $data : '{"ok":false}';
  exit;
}

if (in_array($action, ['comments', 'ratings', 'requests', 'latest'], true)) {
  $map = [
    'comments' => 'palfin_comments.php',
    'ratings' => 'palfin_ratings.php',
    'requests' => 'palfin_requests.php',
    'latest' => is_file($BASE . '/fetch_latest_uploads.php') ? 'fetch_latest_uploads.php' : 'latest_Uploads.php',
  ];
  $file = $map[$action];
  if (!is_file($BASE . '/' . $file)) j_err($file . ' missing', 404);
  $q = $_GET; unset($q['action']);
  $target = abs_url($file) . (empty($q) ? '' : ('?' . http_build_query($q)));
  if ($_SERVER['REQUEST_METHOD'] === 'POST') list($st, $data) = curl_post($target, $body);
  else list($st, $data) = curl_get($target);
  http_response_code($st ?: 500);
  echo ($data !== false) ? $data : '{}';
  exit;
}

j_err('unknown_action', 400);
