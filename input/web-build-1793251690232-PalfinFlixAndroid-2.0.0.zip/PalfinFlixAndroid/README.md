# PalfinFlix Android 2.0.0

## Server
Upload `palfin_android_api.php` into folder:
`https://palfin.ir/palfinapk/`
(same place as palfintvapk.php, palfinadmin.php, palfin_auth.php)

Admin panel remains `palfinadmin.php` — settings shared via `palfin_settings.json`.

## Open in Android Studio
1. Open folder `PalfinFlixAndroid`
2. Sync Gradle
3. Run

## Features
- Hero from admin IMDb ids
- Genre rows + search + detail
- PIN login (palfin_auth.php)
- Download requires login
- Subscription plans from admin settings
- Offline screen with animation
- Host/domain never shown in UI
