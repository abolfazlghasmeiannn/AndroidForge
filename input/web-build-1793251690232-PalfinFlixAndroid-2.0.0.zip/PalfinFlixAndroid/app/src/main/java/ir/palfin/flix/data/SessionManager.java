package ir.palfin.flix.data;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private final SharedPreferences sp;
    public SessionManager(Context ctx) {
        sp = ctx.getSharedPreferences("palfin_auth_v1", Context.MODE_PRIVATE);
    }
    public void save(String token, String chatId, String name, String photoUrl) {
        sp.edit().putString("token", token).putString("chat_id", chatId)
                .putString("name", name).putString("photo_url", photoUrl).apply();
    }
    public void clear() { sp.edit().clear().apply(); }
    public boolean isLoggedIn() {
        String c = getChatId();
        return c != null && !c.isEmpty() && !"123".equals(c);
    }
    public String getToken() { return sp.getString("token", null); }
    public String getChatId() { return sp.getString("chat_id", null); }
    public String getName() { return sp.getString("name", "کاربر"); }
    public String getPhotoUrl() { return sp.getString("photo_url", null); }
}
