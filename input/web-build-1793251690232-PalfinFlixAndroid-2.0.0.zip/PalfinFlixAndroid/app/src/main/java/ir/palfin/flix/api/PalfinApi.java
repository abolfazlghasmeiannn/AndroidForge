package ir.palfin.flix.api;

import com.google.gson.JsonObject;
import java.util.Map;
import ir.palfin.flix.model.AuthCreateResponse;
import ir.palfin.flix.model.AuthStatusResponse;
import ir.palfin.flix.model.SettingsResponse;
import ir.palfin.flix.model.TmdbListResponse;
import ir.palfin.flix.model.TmdbMovie;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface PalfinApi {
    @GET("palfin_android_api.php")
    Call<JsonObject> config(@Query("action") String action);

    @GET("palfin_android_api.php")
    Call<SettingsResponse> settings(@Query("action") String action);

    @GET("palfin_android_api.php")
    Call<TmdbListResponse> tmdbList(@Query("action") String action, @Query("path") String path, @QueryMap Map<String, String> params);

    @GET("palfin_android_api.php")
    Call<TmdbMovie> tmdbDetail(@Query("action") String action, @Query("path") String path, @QueryMap Map<String, String> params);

    @GET("palfin_android_api.php")
    Call<JsonObject> tmdbRaw(@Query("action") String action, @Query("path") String path, @QueryMap Map<String, String> params);

    @GET("palfin_android_api.php")
    Call<JsonObject> downloadUrl(@Query("action") String action, @Query("imdb_id") String imdb, @Query("chat_id") String chat);

    @POST("palfin_auth.php")
    Call<AuthCreateResponse> authCreate(@Query("action") String action, @Body Map<String, String> body);

    @GET("palfin_auth.php")
    Call<AuthStatusResponse> authStatus(@Query("action") String action, @Query("pin") String pin);
}
