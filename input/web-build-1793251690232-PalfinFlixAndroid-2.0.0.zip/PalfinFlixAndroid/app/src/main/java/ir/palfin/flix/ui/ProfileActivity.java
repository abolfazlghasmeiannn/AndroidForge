package ir.palfin.flix.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import ir.palfin.flix.PalfinApp;
import ir.palfin.flix.R;
import ir.palfin.flix.data.SessionManager;

public class ProfileActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnLogin).setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));
    }
    @Override protected void onResume() { super.onResume(); bind(); }
    private void bind() {
        SessionManager s = PalfinApp.get().session();
        TextView name = findViewById(R.id.txtName);
        TextView user = findViewById(R.id.txtUsername);
        MaterialButton login = findViewById(R.id.btnLogin);
        ImageView avatar = findViewById(R.id.imgAvatar);
        if (s.isLoggedIn()) {
            name.setVisibility(View.VISIBLE); user.setVisibility(View.VISIBLE); login.setVisibility(View.GONE);
            name.setText(s.getName()); user.setText(s.getChatId());
            if (s.getPhotoUrl() != null && !s.getPhotoUrl().isEmpty()) {
                avatar.setVisibility(View.VISIBLE);
                Glide.with(this).load(s.getPhotoUrl()).circleCrop().into(avatar);
            }
        } else {
            name.setVisibility(View.GONE); user.setVisibility(View.GONE); login.setVisibility(View.VISIBLE);
        }
    }
}
