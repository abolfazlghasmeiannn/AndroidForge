package ir.palfin.flix.model;
import java.util.List;
public class TmdbListResponse { public int page; public List<TmdbMovie> results; }
