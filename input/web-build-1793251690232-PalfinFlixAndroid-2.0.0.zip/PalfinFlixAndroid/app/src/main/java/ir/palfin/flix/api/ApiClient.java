package ir.palfin.flix.api;

import java.util.concurrent.TimeUnit;
import ir.palfin.flix.util.SecureHost;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class ApiClient {
    private static PalfinApi api;
    private ApiClient() {}

    public static void init() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .build();
        api = new Retrofit.Builder()
                .baseUrl(SecureHost.base())
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(PalfinApi.class);
    }

    public static PalfinApi api() {
        if (api == null) init();
        return api;
    }

    public static String poster(String path) {
        if (path == null || path.isEmpty()) return null;
        String f = path.startsWith("/") ? path.substring(1) : path;
        return SecureHost.base() + "palfintvapk.php?tmdb_img=1&cat=posters&size=w342&path=" + f;
    }

    public static String backdrop(String path) {
        if (path == null || path.isEmpty()) return null;
        String f = path.startsWith("/") ? path.substring(1) : path;
        return SecureHost.base() + "palfintvapk.php?tmdb_img=1&cat=backdrops&size=w1280&path=" + f;
    }
}
