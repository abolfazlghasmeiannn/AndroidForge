package ir.palfin.flix.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class SettingsStore {
    private final SharedPreferences sp;
    private final Gson gson = new Gson();
    private JsonObject cache;

    public SettingsStore(Context ctx) {
        sp = ctx.getSharedPreferences("palfin_settings_v1", Context.MODE_PRIVATE);
        String raw = sp.getString("json", null);
        if (raw != null) try { cache = gson.fromJson(raw, JsonObject.class); } catch (Exception ignored) {}
    }
    public void save(JsonObject s) {
        cache = s;
        if (s != null) sp.edit().putString("json", gson.toJson(s)).apply();
    }
    public JsonObject get() { return cache; }
}
