package ir.palfin.flix;

import android.app.Application;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.data.SessionManager;
import ir.palfin.flix.data.SettingsStore;

public class PalfinApp extends Application {
    private static PalfinApp instance;
    private SessionManager session;
    private SettingsStore settings;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        session = new SessionManager(this);
        settings = new SettingsStore(this);
        ApiClient.init();
    }
    public static PalfinApp get() { return instance; }
    public SessionManager session() { return session; }
    public SettingsStore settings() { return settings; }
}
