package ir.palfin.flix.ui;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import androidx.appcompat.app.AppCompatActivity;
import ir.palfin.flix.R;
import ir.palfin.flix.util.NetworkUtil;

public class OfflineActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);
        View pulse = findViewById(R.id.pulseDot);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(pulse, View.SCALE_X, 0.85f, 1.15f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(pulse, View.SCALE_Y, 0.85f, 1.15f);
        scaleX.setDuration(900); scaleY.setDuration(900);
        scaleX.setRepeatMode(ValueAnimator.REVERSE); scaleY.setRepeatMode(ValueAnimator.REVERSE);
        scaleX.setRepeatCount(ValueAnimator.INFINITE); scaleY.setRepeatCount(ValueAnimator.INFINITE);
        scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleX.start(); scaleY.start();

        findViewById(R.id.btnRetry).setOnClickListener(v -> {
            if (NetworkUtil.isOnline(this)) {
                startActivity(new Intent(this, SplashActivity.class));
                finish();
            }
        });
    }
}
