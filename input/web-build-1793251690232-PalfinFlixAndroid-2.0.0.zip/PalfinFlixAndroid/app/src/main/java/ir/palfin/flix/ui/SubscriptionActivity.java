package ir.palfin.flix.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import ir.palfin.flix.PalfinApp;
import ir.palfin.flix.R;
import java.util.Locale;

public class SubscriptionActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        JsonObject s = PalfinApp.get().settings().get();
        JsonObject sub = s != null && s.has("subscription") ? s.getAsJsonObject("subscription") : null;
        TextView title = findViewById(R.id.txtTitle);
        TextView desc = findViewById(R.id.txtDesc);
        if (sub != null) {
            if (sub.has("mainTitle")) title.setText(sub.get("mainTitle").getAsString());
            if (sub.has("descText")) desc.setText(sub.get("descText").getAsString());
            if (sub.has("logoUrl") && !sub.get("logoUrl").getAsString().isEmpty()) {
                Glide.with(this).load(sub.get("logoUrl").getAsString()).into((android.widget.ImageView) findViewById(R.id.imgLogo));
            }
        }
        LinearLayout box = findViewById(R.id.plansContainer);
        JsonArray plans = sub != null && sub.has("plans") ? sub.getAsJsonArray("plans") : null;
        if (plans != null) {
            for (int i = 0; i < plans.size(); i++) {
                JsonObject p = plans.get(i).getAsJsonObject();
                int planId = p.has("id") ? p.get("id").getAsInt() : (i + 1);
                String label = p.has("label") ? p.get("label").getAsString() : ("پلن " + planId);
                long price = p.has("price") ? p.get("price").getAsLong() : 0;
                MaterialButton btn = new MaterialButton(this);
                btn.setText(label + "  ·  " + String.format(Locale.US, "%,d", price) + " تومان");
                btn.setBackgroundColor(0xFF1A1A1A);
                btn.setTextColor(0xFFFFFFFF);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.topMargin = 12; btn.setLayoutParams(lp); btn.setGravity(Gravity.CENTER);
                btn.setOnClickListener(v -> buy(planId));
                box.addView(btn);
            }
        }
    }
    private void buy(int planId) {
        String chat = PalfinApp.get().session().getChatId();
        if (chat == null || chat.isEmpty()) {
            Toast.makeText(this, R.string.login_required, Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            return;
        }
        // Payment URL opened silently — not displayed
        String url = "https://codexia.ir/payment/request.php?plan=" + planId + "&chat_id=" + Uri.encode(chat);
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
}
