package ir.palfin.flix.util;

import ir.palfin.flix.BuildConfig;

/** Host never exposed in UI / logs intended for users */
public final class SecureHost {
    private SecureHost() {}
    public static String base() {
        String b = BuildConfig.API_HOST;
        return b.endsWith("/") ? b : b + "/";
    }
}
