package ir.palfin.flix.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;
import java.util.List;
import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbMovie;

public class HeroAdapter extends RecyclerView.Adapter<HeroAdapter.VH> {
    public interface Listener { void onOpen(TmdbMovie m); }
    private final List<TmdbMovie> items = new ArrayList<>();
    private final Listener listener;
    public HeroAdapter(Listener l) { listener = l; }
    public void submit(List<TmdbMovie> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_hero, p, false));
    }
    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        TmdbMovie m = items.get(pos);
        h.title.setText(m.displayTitle());
        h.overview.setText(m.overview != null ? m.overview : "");
        Glide.with(h.poster).load(ApiClient.poster(m.posterPath)).into(h.poster);
        Glide.with(h.backdrop).load(ApiClient.backdrop(m.backdropPath != null ? m.backdropPath : m.posterPath)).into(h.backdrop);
        View.OnClickListener open = v -> { if (listener != null) listener.onOpen(m); };
        h.cta.setOnClickListener(open);
        h.itemView.setOnClickListener(open);
    }
    @Override public int getItemCount() { return items.size(); }
    static class VH extends RecyclerView.ViewHolder {
        ImageView backdrop, poster; TextView title, overview; MaterialButton cta;
        VH(@NonNull View v) {
            super(v);
            backdrop = v.findViewById(R.id.imgBackdrop);
            poster = v.findViewById(R.id.imgPoster);
            title = v.findViewById(R.id.txtTitle);
            overview = v.findViewById(R.id.txtOverview);
            cta = v.findViewById(R.id.btnHeroCta);
        }
    }
}
