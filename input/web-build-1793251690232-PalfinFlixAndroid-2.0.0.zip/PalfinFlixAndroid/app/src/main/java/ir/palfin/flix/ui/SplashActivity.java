package ir.palfin.flix.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.JsonObject;
import ir.palfin.flix.R;
import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.SettingsResponse;
import ir.palfin.flix.PalfinApp;
import ir.palfin.flix.util.NetworkUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity {
    private boolean opened;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        TextView logo = findViewById(R.id.txtLogo);
        logo.animate().alpha(1f).setDuration(700).setInterpolator(new DecelerateInterpolator()).start();

        if (!NetworkUtil.isOnline(this)) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                startActivity(new Intent(this, OfflineActivity.class));
                finish();
            }, 800);
            return;
        }

        ApiClient.api().settings("settings").enqueue(new Callback<SettingsResponse>() {
            @Override public void onResponse(Call<SettingsResponse> call, Response<SettingsResponse> response) {
                if (response.body() != null && response.body().settings != null) {
                    PalfinApp.get().settings().save(response.body().settings);
                }
                goMain();
            }
            @Override public void onFailure(Call<SettingsResponse> call, Throwable t) {
                // still try home; offline only if completely no network
                goMain();
            }
        });
        new Handler(Looper.getMainLooper()).postDelayed(this::goMain, 2800);
    }
    private void goMain() {
        if (opened) return;
        opened = true;
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
