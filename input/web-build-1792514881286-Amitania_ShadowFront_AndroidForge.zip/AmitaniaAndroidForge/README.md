# AMITANIA: SHADOW FRONT — AndroidForge Edition

A small offline, landscape Android game demo built as a native Android WebView app with an HTML5 Canvas game. This project is designed to be uploaded as a ZIP to AndroidForge, which builds Android Gradle projects.

## Build with AndroidForge
1. Upload this ZIP to your AndroidForge fork using its web UI.
2. Choose `auto` or `debug` build variant.
3. Start the build and download the APK from the GitHub Actions run when complete.

AndroidForge project: https://github.com/Professional-X/AndroidForge
Web UI: https://professional-x.github.io/AndroidForge/

## Gameplay
- Offline single-player arcade shooter demo
- Landscape mode and fullscreen presentation
- Touch movement pad, Fire, Reload and Aim controls
- Hostile soldiers, enemy projectiles, player health, ammo, waves and mission screens
- All game graphics are drawn in Canvas; no remote assets or network permission required

## Technical
- Android Gradle project (Java Activity + local HTML/CSS/JavaScript)
- Application ID: `com.amitaniashadowfront.game`
- Minimum Android: API 23 (Android 6.0)
- Compile/target SDK: 35
- Android Gradle Plugin: 8.7.3

This is an early prototype, not a commercial-grade 3D FPS. It uses a top-down 2D arcade view so it can be built by AndroidForge without the Unity editor. If build fails, check the AndroidForge Actions log for the exact error.
