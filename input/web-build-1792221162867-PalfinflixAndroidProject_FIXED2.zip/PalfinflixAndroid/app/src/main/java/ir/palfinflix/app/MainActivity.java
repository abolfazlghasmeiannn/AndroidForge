package ir.palfinflix.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.animation.Animation;
import android.view.animation.AlphaAnimation;
import android.view.animation.RotateAnimation;
import android.graphics.drawable.ColorDrawable;

public class MainActivity extends Activity {
    private static final String HOME = "https://palfin.ir/palfinapk/palfintvapk.php";
    private FrameLayout root;
    private WebView web;
    private View offlineView;
    private boolean pageFailed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,8,8));
        setContentView(root);
        buildWebView();
        if (hasInternet()) web.loadUrl(HOME); else showOffline();
    }

    private void buildWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,8,8));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUserAgentString(s.getUserAgentString());
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep navigation inside the app; no browser address bar is shown.
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
                if (offlineView != null) { root.removeView(offlineView); offlineView = null; }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) { pageFailed = true; showOffline(); }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) showOffline();
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!pageFailed && offlineView != null) { root.removeView(offlineView); offlineView = null; }
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
    }

    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return true; }
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void showOffline() {
        runOnUiThread(() -> {
            if (offlineView != null) root.removeView(offlineView);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setPadding(30,30,30,30);
            page.setBackgroundColor(Color.rgb(8,8,8));

            TextView brand = new TextView(this);
            brand.setText("PALFINFLIX"); brand.setTextColor(Color.rgb(229,9,20));
            brand.setTextSize(27); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            brand.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.bottomMargin=48;
            page.addView(brand,bp);

            FrameLayout iconBox = new FrameLayout(this);
            iconBox.setBackground(rounded(Color.rgb(28,28,28), 100));
            LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(190,190); ibp.bottomMargin=28;
            page.addView(iconBox,ibp);
            TextView wifi = new TextView(this);
            wifi.setText("⌁"); wifi.setTextColor(Color.rgb(229,9,20)); wifi.setTextSize(74);
            wifi.setGravity(Gravity.CENTER);
            iconBox.addView(wifi,new FrameLayout.LayoutParams(-1,-1));
            AlphaAnimation pulse = new AlphaAnimation(0.35f,1f); pulse.setDuration(900); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE); wifi.startAnimation(pulse);

            TextView title = new TextView(this);
            title.setText("اتصال برقرار نشد"); title.setTextColor(Color.WHITE); title.setTextSize(21);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
            page.addView(title);
            TextView desc = new TextView(this);
            desc.setText("اینترنت خود را چک کنید"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(16);
            desc.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=10; dp.bottomMargin=28;
            page.addView(desc,dp);
            TextView retry = new TextView(this);
            retry.setText("تلاش مجدد"); retry.setTextColor(Color.WHITE); retry.setTextSize(16); retry.setGravity(Gravity.CENTER);
            retry.setPadding(42,16,42,16); retry.setBackground(rounded(Color.rgb(229,9,20),50));
            retry.setOnClickListener(v -> { if (hasInternet()) { if (offlineView != null) root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else { wifi.clearAnimation(); wifi.startAnimation(pulse); } });
            page.addView(retry);
            offlineView = page;
            root.addView(offlineView,new FrameLayout.LayoutParams(-1,-1));
        });
    }

    @Override public void onBackPressed() {
        if (offlineView != null) { if (hasInternet()) { root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else super.onBackPressed(); }
        else if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
