امضای دائمی PalfinFlix
=========================
این پروژه دارای keystore ثابت است تا نسخه‌های بعدی APK با همان امضا ساخته شوند.
Package: site.palfinflix.app
Alias: palfinflix
Validity: 10000 days

فایل palfinflix-release-key.jks و gradle.properties محرمانه‌اند.
هرگز پروژه حاوی کلید را در مخزن عمومی GitHub یا در اختیار افراد ناشناس قرار ندهید.
از فایل keystore یک نسخه پشتیبان آفلاین جداگانه نگه دارید.
اگر keystore یا رمزها گم شوند، دیگر نمی‌توان APKهای آینده را با امضای فعلی ساخت.
AndroidForge در حالت پیش‌فرض امضای release را خودکار با کلید ثابت انجام نمی‌دهد؛
این پروژه signingConfig را برای debug و release تنظیم کرده است، اما باید خروجی AndroidForge
بررسی شود تا مطمئن شوید build variant انتخابی این تنظیم را اعمال کرده است.
