PalfinFlix 2.0.0 — تغییر آدرس سایت

آدرس صفحه شروع WebView: https://palfinflix.ir/palfinapk/palfintvapp.php
Package: site.palfinflix.app
VersionName: 2.0.0
VersionCode: 9
Update API: https://codexia.ir/app/check-update.php

این ZIP شامل پروژه Android/Gradle و کلید امضای قبلی پروژه است. کلید و رمز آن محرمانه است؛ آن را در مخزن عمومی یا برای دیگران ارسال نکنید.

نکته درباره مخفی‌سازی URL: آدرس مقصد WebView را نمی‌توان از APK به‌طور قطعی مخفی کرد. رمزگذاری/obfuscation فقط استخراج را دشوارتر می‌کند و راه تضمینی برای جلوگیری از فیلترینگ نیست. از HTTPS، کنترل مقصدهای مجاز WebView، نگهداری کلید امضا امن، و محدود کردن دسترسی سرور به‌عنوان اقدامات امنیتی واقعی استفاده کنید. این پروژه برای دور زدن فیلترینگ تغییر یا تضمین نمی‌کند.

APK در این محیط ساخته و روی دستگاه آزمایش نشده است. AndroidForge باید سازگاری پروژه و signing config را تأیید کند.
