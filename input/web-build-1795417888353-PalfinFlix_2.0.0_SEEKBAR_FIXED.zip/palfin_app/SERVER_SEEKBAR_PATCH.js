/**
 * Server-side patch for palfintvapp.php player seek bar.
 * Replace the existing seekFromClientX + barWrap pointer binding
 * inside streamPlayerPlayUrl with this logic.
 *
 * Key changes:
 * - axis-aware percent (works with rotate(90deg) landscape UI)
 * - UI-only updates while dragging; commit currentTime on pointer/touch end
 */

function pctFromPoint(clientX, clientY, rect) {
  if (!rect) return 0;
  var pct;
  // After CSS rotate(90deg) the visual bar is often taller than wide.
  if (rect.width >= rect.height) {
    pct = (clientX - rect.left) / Math.max(1, rect.width);
  } else {
    pct = (clientY - rect.top) / Math.max(1, rect.height);
  }
  return Math.max(0, Math.min(1, pct));
}

var _seekRaf = null;
var _seekTarget = null;

function seekFromClientXY(clientX, clientY, commit) {
  if (!v) return;
  var bar = document.getElementById('pfvBar');
  if (!bar) return;
  var rect = bar.getBoundingClientRect();
  var pct = pctFromPoint(clientX, clientY, rect);
  var dur = v.duration;
  var t = (isFinite(dur) && dur > 0) ? (pct * dur) : 0;

  var fill = document.getElementById('pfvFill');
  var knob = document.getElementById('pfvKnob');
  var curEl = document.getElementById('pfvCur');
  var remEl = document.getElementById('pfvRem');
  if (fill) fill.style.width = (pct * 100) + '%';
  if (knob) knob.style.left = (pct * 100) + '%';

  if (isFinite(dur) && dur > 0) {
    if (curEl) curEl.textContent = pfvFmt(t);
    if (remEl) remEl.textContent = '-' + pfvFmt(Math.max(0, dur - t));
    _seekTarget = t;
    if (commit) {
      try { v.currentTime = t; } catch (e) {}
      _seekTarget = null;
    }
    // IMPORTANT for WebView smoothness:
    // do NOT assign currentTime on every move; only on commit (finger up).
  }
}

// Binding example (replace old pointerdown block on #pfvBarWrap):
/*
var barWrap = document.getElementById('pfvBarWrap');
if (barWrap) {
  barWrap.addEventListener('pointerdown', function (e) {
    if (pfvState.locked) return;
    e.preventDefault(); e.stopPropagation();
    pfvState.seeking = true;
    barWrap.classList.add('is-seeking');
    try { barWrap.setPointerCapture(e.pointerId); } catch (err) {}
    seekFromClientXY(e.clientX, e.clientY, false);
    pfvShowUI();

    var move = function (ev) {
      ev.preventDefault();
      seekFromClientXY(ev.clientX, ev.clientY, false);
    };
    var up = function (ev) {
      pfvState.seeking = false;
      barWrap.classList.remove('is-seeking');
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      if (ev && typeof ev.clientX === 'number') {
        seekFromClientXY(ev.clientX, ev.clientY, true);
      } else if (_seekTarget != null) {
        try { v.currentTime = _seekTarget; } catch (err) {}
      }
      try { if (v) pfvCwSave(v.currentTime, v.duration); } catch (err) {}
      pfvShowUI();
    };
    window.addEventListener('pointermove', move, { passive: false });
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
  });
}
*/
