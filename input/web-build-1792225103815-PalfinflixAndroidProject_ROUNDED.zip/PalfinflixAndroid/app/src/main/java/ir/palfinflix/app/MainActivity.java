package ir.palfinflix.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.animation.Animation;
import android.view.animation.AlphaAnimation;

public class MainActivity extends Activity {
    private static final String HOME = "https://palfin.ir/palfinapk/palfintvapk.php";
    private FrameLayout root;
    private WebView web;
    private View offlineView;
    private View loadingView;
    private boolean pageFailed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,8,8));
        setContentView(root);
        buildWebView();
        if (hasInternet()) { showLoading(); web.loadUrl(HOME); } else showOffline();
    }

    private void buildWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,8,8));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUserAgentString(s.getUserAgentString());
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, false); return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, true); return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                showNativeMessage(message, null, result, false, defaultValue); return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep navigation inside the app; no browser address bar is shown.
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
                if (offlineView != null) { root.removeView(offlineView); offlineView = null; }
                showLoading();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) { pageFailed = true; showOffline(); }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) showOffline();
            }
            @Override public void onPageCommitVisible(WebView view, String url) {
                // Hide the splash as soon as the first page content is ready to be drawn.
                if (!pageFailed) hideLoading();
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!pageFailed && offlineView != null) { root.removeView(offlineView); offlineView = null; }
                // Fallback for pages/WebView versions where commit-visible is not called.
                hideLoading();
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
    }

    private void showLoading() {
        runOnUiThread(() -> {
            if (offlineView != null) return;
            if (loadingView != null) return;
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setPadding(28, 32, 28, 32);
            page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(18,18,18), Color.rgb(5,5,5), Color.rgb(24,5,8)}));

            FrameLayout logoWrap = new FrameLayout(this);
            GradientDrawable tile = new GradientDrawable();
            tile.setColor(Color.rgb(20, 8, 10));
            tile.setCornerRadius(30);
            tile.setStroke(2, Color.rgb(229,9,20));
            logoWrap.setBackground(tile);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(124,124);
            lp.bottomMargin = 24;
            page.addView(logoWrap, lp);
            ImageView logo = new ImageView(this);
            int logoId = getResources().getIdentifier("palfinflix_logo", "drawable", getPackageName());
            if (logoId != 0) logo.setImageResource(logoId);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            GradientDrawable logoBackground = new GradientDrawable();
            logoBackground.setColor(Color.BLACK);
            logoBackground.setCornerRadius(22);
            logo.setBackground(logoBackground);
            if (android.os.Build.VERSION.SDK_INT >= 21) logo.setClipToOutline(true);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(92,92,Gravity.CENTER);
            logoWrap.addView(logo, ilp);
            // The brand icon stays still: no continuous rotation or pulsing animation.

            TextView brand = new TextView(this);
            brand.setText("پالفین‌فلیکس"); brand.setTextColor(Color.WHITE); brand.setTextSize(28);
            brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD); brand.setGravity(Gravity.CENTER);
            page.addView(brand);
            TextView caption = new TextView(this);
            caption.setText("درحال بارگذاری، صبر کنید..."); caption.setTextColor(Color.LTGRAY);
            caption.setTextSize(15); caption.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=12; cp.bottomMargin=26;
            page.addView(caption,cp);
            ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progress.setIndeterminate(true);
            if (android.os.Build.VERSION.SDK_INT >= 21) progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(229,9,20)));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(150,5); page.addView(progress,pp);
            loadingView = page;
            root.addView(loadingView,new FrameLayout.LayoutParams(-1,-1));
        });
    }

    private void hideLoading() {
        runOnUiThread(() -> {
            if (loadingView == null) return;
            View old = loadingView; loadingView = null;
            old.animate().alpha(0f).setDuration(120).withEndAction(() -> root.removeView(old)).start();
        });
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm) {
        showNativeMessage(message, jsResult, promptResult, confirm, "");
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm, String defaultValue) {
        runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK);
            builder.setTitle("پالفین‌فلیکس");
            builder.setMessage(message == null ? "" : message);
            if (promptResult != null) {
                EditText input = new EditText(this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY);
                builder.setView(input);
                builder.setPositiveButton("تأیید", (d,w) -> promptResult.confirm(input.getText().toString()));
                builder.setNegativeButton("لغو", (d,w) -> promptResult.cancel());
                builder.setOnCancelListener(d -> promptResult.cancel());
            } else if (confirm) {
                builder.setPositiveButton("تأیید", (d,w) -> jsResult.confirm());
                builder.setNegativeButton("لغو", (d,w) -> jsResult.cancel());
                builder.setOnCancelListener(d -> jsResult.cancel());
            } else {
                builder.setPositiveButton("متوجه شدم", (d,w) -> jsResult.confirm());
                builder.setOnCancelListener(d -> jsResult.confirm());
            }
            try { builder.create().show(); }
            catch (Exception e) { if (jsResult != null) jsResult.cancel(); if (promptResult != null) promptResult.cancel(); }
        });
    }

    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return true; }
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void showOffline() {
        runOnUiThread(() -> {
            hideLoading();
            if (offlineView != null) root.removeView(offlineView);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setPadding(30,30,30,30);
            page.setBackgroundColor(Color.rgb(8,8,8));

            TextView brand = new TextView(this);
            brand.setText("PALFINFLIX"); brand.setTextColor(Color.rgb(229,9,20));
            brand.setTextSize(27); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            brand.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.bottomMargin=48;
            page.addView(brand,bp);

            FrameLayout iconBox = new FrameLayout(this);
            iconBox.setBackground(rounded(Color.rgb(28,28,28), 100));
            LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(190,190); ibp.bottomMargin=28;
            page.addView(iconBox,ibp);
            TextView wifi = new TextView(this);
            wifi.setText("⌁"); wifi.setTextColor(Color.rgb(229,9,20)); wifi.setTextSize(74);
            wifi.setGravity(Gravity.CENTER);
            iconBox.addView(wifi,new FrameLayout.LayoutParams(-1,-1));
            AlphaAnimation pulse = new AlphaAnimation(0.35f,1f); pulse.setDuration(900); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE); wifi.startAnimation(pulse);

            TextView title = new TextView(this);
            title.setText("اتصال برقرار نشد"); title.setTextColor(Color.WHITE); title.setTextSize(21);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
            page.addView(title);
            TextView desc = new TextView(this);
            desc.setText("اینترنت خود را چک کنید"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(16);
            desc.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=10; dp.bottomMargin=28;
            page.addView(desc,dp);
            TextView retry = new TextView(this);
            retry.setText("تلاش مجدد"); retry.setTextColor(Color.WHITE); retry.setTextSize(16); retry.setGravity(Gravity.CENTER);
            retry.setPadding(42,16,42,16); retry.setBackground(rounded(Color.rgb(229,9,20),50));
            retry.setOnClickListener(v -> { if (hasInternet()) { if (offlineView != null) root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else { wifi.clearAnimation(); wifi.startAnimation(pulse); } });
            page.addView(retry);
            offlineView = page;
            root.addView(offlineView,new FrameLayout.LayoutParams(-1,-1));
        });
    }

    @Override public void onBackPressed() {
        if (offlineView != null) { if (hasInternet()) { root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else super.onBackPressed(); }
        else if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
