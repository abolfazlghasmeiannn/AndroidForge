const api = window.palfinDesktop;
document.getElementById('minimize').addEventListener('click', () => api.minimize());
document.getElementById('maximize').addEventListener('click', () => api.toggleMaximize());
document.getElementById('close').addEventListener('click', () => api.close());
