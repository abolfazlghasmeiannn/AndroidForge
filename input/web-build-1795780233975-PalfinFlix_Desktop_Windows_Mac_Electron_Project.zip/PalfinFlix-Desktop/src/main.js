const { app, BrowserWindow, WebContentsView, ipcMain, shell } = require('electron');
const path = require('path');

const APP_URL = 'https://palfinflix.ir/palfinapk/palfintvvin.php';
const APP_HOST = 'palfinflix.ir';
const TITLEBAR_HEIGHT = 48;
let mainWindow;
let siteView;

function isAppUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return url.protocol === 'https:' && url.hostname === APP_HOST;
  } catch {
    return false;
  }
}

function layoutSiteView() {
  if (!mainWindow || !siteView) return;
  const [width, height] = mainWindow.getContentSize();
  siteView.setBounds({ x: 0, y: TITLEBAR_HEIGHT, width, height: Math.max(0, height - TITLEBAR_HEIGHT) });
  siteView.setAutoResize({ width: true, height: true });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 900,
    minHeight: 600,
    show: false,
    center: true,
    frame: false,
    title: 'PalfinFlix',
    backgroundColor: '#09090b',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());

  siteView = new WebContentsView({
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true
    }
  });
  mainWindow.contentView.addChildView(siteView);
  layoutSiteView();
  mainWindow.on('resize', layoutSiteView);

  siteView.webContents.setWindowOpenHandler(({ url }) => {
    if (isAppUrl(url)) siteView.webContents.loadURL(url);
    else shell.openExternal(url);
    return { action: 'deny' };
  });
  siteView.webContents.on('will-navigate', (event, url) => {
    if (!isAppUrl(url)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });
  siteView.webContents.loadURL(APP_URL);

  mainWindow.on('closed', () => {
    mainWindow = null;
    siteView = null;
  });
}

ipcMain.on('window:minimize', () => mainWindow?.minimize());
ipcMain.on('window:toggle-maximize', () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.on('window:close', () => mainWindow?.close());
ipcMain.handle('window:is-maximized', () => !!mainWindow?.isMaximized());

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
