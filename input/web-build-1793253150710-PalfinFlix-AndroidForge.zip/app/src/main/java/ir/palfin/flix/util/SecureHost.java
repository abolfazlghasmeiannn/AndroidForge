package ir.palfin.flix.util;
import ir.palfin.flix.BuildConfig;
public final class SecureHost {
    private SecureHost(){}
    public static String base(){ String b=BuildConfig.API_HOST; return b.endsWith("/")?b:b+"/"; }
}
