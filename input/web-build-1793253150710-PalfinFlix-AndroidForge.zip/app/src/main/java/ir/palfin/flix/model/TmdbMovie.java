package ir.palfin.flix.model;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class TmdbMovie {
    public int id; public String title; public String name; public String overview;
    @SerializedName("poster_path") public String posterPath;
    @SerializedName("backdrop_path") public String backdropPath;
    @SerializedName("vote_average") public double voteAverage;
    @SerializedName("media_type") public String mediaType;
    @SerializedName("imdb_id") public String imdbId;
    public List<Genre> genres;
    @SerializedName("production_countries") public List<Country> productionCountries;
    public static class Genre { public String name; }
    public static class Country { @SerializedName("iso_3166_1") public String iso; }
    public String displayTitle(){ if(title!=null&&!title.isEmpty())return title; if(name!=null&&!name.isEmpty())return name; return "—"; }
    public String type(){ if("tv".equalsIgnoreCase(mediaType)||(name!=null&&(title==null||title.isEmpty()))) return "tv"; return "movie"; }
}
