package ir.palfin.flix.ui;
import android.animation.ObjectAnimator; import android.animation.ValueAnimator;
import android.content.Intent; import android.os.Bundle; import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import androidx.appcompat.app.AppCompatActivity;
import ir.palfin.flix.R; import ir.palfin.flix.util.NetworkUtil;
public class OfflineActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_offline);
        View p=findViewById(R.id.pulse);
        ObjectAnimator x=ObjectAnimator.ofFloat(p, View.SCALE_X, 0.85f, 1.12f);
        ObjectAnimator y=ObjectAnimator.ofFloat(p, View.SCALE_Y, 0.85f, 1.12f);
        x.setDuration(900); y.setDuration(900);
        x.setRepeatMode(ValueAnimator.REVERSE); y.setRepeatMode(ValueAnimator.REVERSE);
        x.setRepeatCount(ValueAnimator.INFINITE); y.setRepeatCount(ValueAnimator.INFINITE);
        x.setInterpolator(new AccelerateDecelerateInterpolator()); y.setInterpolator(new AccelerateDecelerateInterpolator());
        x.start(); y.start();
        findViewById(R.id.btnRetry).setOnClickListener(v->{
            if(NetworkUtil.isOnline(this)){ startActivity(new Intent(this, SplashActivity.class)); finish(); }
        });
    }
}
