package ir.palfin.flix.ui;
import android.content.Intent; import android.os.Bundle; import android.view.inputmethod.EditorInfo;
import android.widget.EditText; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity; import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.HashMap; import java.util.Map;
import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient; import ir.palfin.flix.model.TmdbListResponse;
import retrofit2.Call; import retrofit2.Callback; import retrofit2.Response;
public class SearchActivity extends AppCompatActivity {
    private PosterAdapter adapter;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_search);
        RecyclerView rv=findViewById(R.id.results); rv.setLayoutManager(new GridLayoutManager(this,3));
        adapter=new PosterAdapter(m->{ Intent i=new Intent(this, DetailActivity.class); i.putExtra("type",m.type()); i.putExtra("id",m.id); startActivity(i); });
        rv.setAdapter(adapter);
        EditText q=findViewById(R.id.query);
        q.setOnEditorActionListener((v,a,e)->{ if(a==EditorInfo.IME_ACTION_SEARCH){ search(q.getText().toString().trim()); return true; } return false; });
    }
    private void search(String q){ if(q.isEmpty()) return;
        Map<String,String> p=new HashMap<>(); p.put("query",q); p.put("include_adult","false");
        ApiClient.api().tmdbList("tmdb","/search/multi", p).enqueue(new Callback<TmdbListResponse>(){
            @Override public void onResponse(Call<TmdbListResponse> c, Response<TmdbListResponse> r){ if(r.body()!=null) adapter.submit(r.body().results); }
            @Override public void onFailure(Call<TmdbListResponse> c, Throwable t){ Toast.makeText(SearchActivity.this,R.string.error_network,Toast.LENGTH_SHORT).show(); }
        });
    }
}
