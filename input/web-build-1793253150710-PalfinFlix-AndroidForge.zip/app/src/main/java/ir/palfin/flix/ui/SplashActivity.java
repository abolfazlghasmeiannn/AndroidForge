package ir.palfin.flix.ui;
import android.content.Intent; import android.os.Bundle; import android.os.Handler; import android.os.Looper;
import android.view.animation.DecelerateInterpolator; import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.SettingsResponse; import ir.palfin.flix.util.NetworkUtil;
import retrofit2.Call; import retrofit2.Callback; import retrofit2.Response;
public class SplashActivity extends AppCompatActivity {
    private boolean opened;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_splash);
        TextView logo=findViewById(R.id.logo);
        logo.animate().alpha(1f).setDuration(700).setInterpolator(new DecelerateInterpolator()).start();
        if(!NetworkUtil.isOnline(this)){ new Handler(Looper.getMainLooper()).postDelayed(()->{ startActivity(new Intent(this, OfflineActivity.class)); finish(); },700); return; }
        ApiClient.api().settings("settings").enqueue(new Callback<SettingsResponse>(){
            @Override public void onResponse(Call<SettingsResponse> c, Response<SettingsResponse> r){
                if(r.body()!=null && r.body().settings!=null) PalfinApp.get().settings().save(r.body().settings);
                go(); }
            @Override public void onFailure(Call<SettingsResponse> c, Throwable t){ go(); }
        });
        new Handler(Looper.getMainLooper()).postDelayed(this::go, 2500);
    }
    private void go(){ if(opened) return; opened=true; startActivity(new Intent(this, MainActivity.class)); finish(); }
}
