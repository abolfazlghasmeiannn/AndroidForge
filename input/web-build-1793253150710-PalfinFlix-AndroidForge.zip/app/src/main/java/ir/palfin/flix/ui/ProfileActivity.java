package ir.palfin.flix.ui;
import android.content.Intent; import android.os.Bundle; import android.view.View; import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R; import ir.palfin.flix.data.SessionManager;
public class ProfileActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_profile);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.btnLogin).setOnClickListener(v-> startActivity(new Intent(this, LoginActivity.class)));
    }
    @Override protected void onResume(){ super.onResume();
        SessionManager s=PalfinApp.get().session(); TextView name=findViewById(R.id.name);
        if(s.isLoggedIn()){ name.setVisibility(View.VISIBLE); name.setText(s.getName()); findViewById(R.id.btnLogin).setVisibility(View.GONE); }
        else { name.setVisibility(View.GONE); findViewById(R.id.btnLogin).setVisibility(View.VISIBLE); }
    }
}
