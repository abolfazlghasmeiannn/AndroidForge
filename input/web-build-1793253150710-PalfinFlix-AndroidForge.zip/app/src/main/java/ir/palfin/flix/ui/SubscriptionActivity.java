package ir.palfin.flix.ui;
import android.content.Intent; import android.net.Uri; import android.os.Bundle;
import android.view.Gravity; import android.widget.Button; import android.widget.LinearLayout; import android.widget.TextView; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.JsonArray; import com.google.gson.JsonObject;
import java.util.Locale;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R;
public class SubscriptionActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_subscription);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        JsonObject s=PalfinApp.get().settings().get();
        JsonObject sub=s!=null && s.has("subscription")? s.getAsJsonObject("subscription"):null;
        if(sub!=null){
            if(sub.has("mainTitle")) ((TextView)findViewById(R.id.title)).setText(sub.get("mainTitle").getAsString());
            if(sub.has("descText")) ((TextView)findViewById(R.id.desc)).setText(sub.get("descText").getAsString());
        }
        LinearLayout box=findViewById(R.id.plans);
        JsonArray plans=sub!=null && sub.has("plans")? sub.getAsJsonArray("plans"):null;
        if(plans!=null) for(int i=0;i<plans.size();i++){
            JsonObject p=plans.get(i).getAsJsonObject();
            int planId=p.has("id")?p.get("id").getAsInt():(i+1);
            String label=p.has("label")?p.get("label").getAsString():("پلن "+planId);
            long price=p.has("price")?p.get("price").getAsLong():0;
            Button btn=new Button(this);
            btn.setText(label+"  ·  "+String.format(Locale.US,"%,d",price)+" تومان");
            btn.setBackgroundResource(R.drawable.bg_card); btn.setTextColor(0xFFFFFFFF);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin=12; btn.setLayoutParams(lp); btn.setGravity(Gravity.CENTER);
            btn.setOnClickListener(v->buy(planId)); box.addView(btn);
        }
    }
    private void buy(int planId){
        String chat=PalfinApp.get().session().getChatId();
        if(chat==null||chat.isEmpty()){ Toast.makeText(this,R.string.login_required,Toast.LENGTH_LONG).show(); startActivity(new Intent(this, LoginActivity.class)); return; }
        String url="https://codexia.ir/payment/request.php?plan="+planId+"&chat_id="+Uri.encode(chat);
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
}
