package ir.palfin.flix.ui;
import android.content.Intent; import android.net.Uri; import android.os.Bundle;
import android.widget.ImageView; import android.widget.TextView; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity; import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide; import com.google.gson.JsonObject;
import java.util.HashMap; import java.util.Locale;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbListResponse; import ir.palfin.flix.model.TmdbMovie;
import retrofit2.Call; import retrofit2.Callback; import retrofit2.Response;
public class DetailActivity extends AppCompatActivity {
    private String type; private int id; private String imdbId="";
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_detail);
        type=getIntent().getStringExtra("type"); if(type==null) type="movie";
        id=getIntent().getIntExtra("id",0);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        findViewById(R.id.btnDownload).setOnClickListener(v->onDownload());
        load(); loadSimilar();
    }
    private void load(){
        ApiClient.api().tmdbDetail("tmdb","/"+type+"/"+id, new HashMap<>()).enqueue(new Callback<TmdbMovie>(){
            @Override public void onResponse(Call<TmdbMovie> c, Response<TmdbMovie> r){ if(r.body()!=null) bind(r.body()); }
            @Override public void onFailure(Call<TmdbMovie> c, Throwable t){ Toast.makeText(DetailActivity.this,R.string.error_network,Toast.LENGTH_SHORT).show(); }
        });
        ApiClient.api().tmdbRaw("tmdb","/"+type+"/"+id+"/external_ids", new HashMap<>()).enqueue(new Callback<JsonObject>(){
            @Override public void onResponse(Call<JsonObject> c, Response<JsonObject> r){
                if(r.body()!=null && r.body().has("imdb_id") && !r.body().get("imdb_id").isJsonNull())
                    imdbId=r.body().get("imdb_id").getAsString();
            }
            @Override public void onFailure(Call<JsonObject> c, Throwable t){}
        });
    }
    private void bind(TmdbMovie m){
        ((TextView)findViewById(R.id.title)).setText(m.displayTitle());
        StringBuilder sb=new StringBuilder();
        if(m.genres!=null && !m.genres.isEmpty()){ sb.append(m.genres.get(0).name); if(m.genres.size()>1) sb.append(" · ").append(m.genres.get(1).name); }
        else sb.append("—");
        sb.append(" | ");
        if(m.productionCountries!=null && !m.productionCountries.isEmpty()) sb.append(m.productionCountries.get(0).iso); else sb.append("—");
        sb.append(" | ★ ").append(String.format(Locale.US,"%.1f", m.voteAverage));
        ((TextView)findViewById(R.id.meta)).setText(sb.toString());
        ((TextView)findViewById(R.id.overview)).setText(m.overview!=null?m.overview:"");
        Glide.with(this).load(ApiClient.poster(m.posterPath)).into((ImageView)findViewById(R.id.poster));
        Glide.with(this).load(ApiClient.backdrop(m.backdropPath!=null?m.backdropPath:m.posterPath)).into((ImageView)findViewById(R.id.backdrop));
        if(m.imdbId!=null && m.imdbId.startsWith("tt")) imdbId=m.imdbId;
    }
    private void loadSimilar(){
        RecyclerView rv=findViewById(R.id.similar);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        PosterAdapter ad=new PosterAdapter(m->{ Intent i=new Intent(this, DetailActivity.class); i.putExtra("type",m.type()); i.putExtra("id",m.id); startActivity(i); });
        rv.setAdapter(ad);
        ApiClient.api().tmdbList("tmdb","/"+type+"/"+id+"/similar", new HashMap<>()).enqueue(new Callback<TmdbListResponse>(){
            @Override public void onResponse(Call<TmdbListResponse> c, Response<TmdbListResponse> r){ if(r.body()!=null) ad.submit(r.body().results); }
            @Override public void onFailure(Call<TmdbListResponse> c, Throwable t){}
        });
    }
    private void onDownload(){
        String chat=PalfinApp.get().session().getChatId();
        if(chat==null || chat.isEmpty() || "123".equals(chat)){
            Toast.makeText(this, R.string.login_required, Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class)); return;
        }
        if(imdbId==null || !imdbId.startsWith("tt")){ Toast.makeText(this,"شناسه محتوا نیست",Toast.LENGTH_SHORT).show(); return; }
        ApiClient.api().downloadUrl("download_url", imdbId, chat).enqueue(new Callback<JsonObject>(){
            @Override public void onResponse(Call<JsonObject> c, Response<JsonObject> r){
                try{
                    if(r.body()!=null && r.body().has("url")){
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(r.body().get("url").getAsString())));
                    }
                }catch(Exception e){ Toast.makeText(DetailActivity.this,R.string.error_network,Toast.LENGTH_SHORT).show(); }
            }
            @Override public void onFailure(Call<JsonObject> c, Throwable t){ Toast.makeText(DetailActivity.this,R.string.error_network,Toast.LENGTH_SHORT).show(); }
        });
    }
}
