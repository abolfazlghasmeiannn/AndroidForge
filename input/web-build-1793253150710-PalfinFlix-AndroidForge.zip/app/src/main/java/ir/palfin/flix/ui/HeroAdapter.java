package ir.palfin.flix.ui;
import android.view.LayoutInflater; import android.view.View; import android.view.ViewGroup;
import android.widget.Button; import android.widget.ImageView; import android.widget.TextView;
import androidx.annotation.NonNull; import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList; import java.util.List;
import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient; import ir.palfin.flix.model.TmdbMovie;
public class HeroAdapter extends RecyclerView.Adapter<HeroAdapter.VH> {
    public interface L { void open(TmdbMovie m); }
    private final List<TmdbMovie> items=new ArrayList<>(); private final L listener;
    public HeroAdapter(L l){ listener=l; }
    public void submit(List<TmdbMovie> list){ items.clear(); if(list!=null) items.addAll(list); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_hero,p,false)); }
    @Override public void onBindViewHolder(@NonNull VH h,int pos){
        TmdbMovie m=items.get(pos);
        h.title.setText(m.displayTitle()); h.overview.setText(m.overview!=null?m.overview:"");
        Glide.with(h.poster).load(ApiClient.poster(m.posterPath)).into(h.poster);
        Glide.with(h.bg).load(ApiClient.backdrop(m.backdropPath!=null?m.backdropPath:m.posterPath)).into(h.bg);
        View.OnClickListener o=v->{ if(listener!=null) listener.open(m); };
        h.cta.setOnClickListener(o); h.itemView.setOnClickListener(o);
    }
    @Override public int getItemCount(){ return items.size(); }
    static class VH extends RecyclerView.ViewHolder {
        ImageView bg,poster; TextView title,overview; Button cta;
        VH(@NonNull View v){ super(v); bg=v.findViewById(R.id.bg); poster=v.findViewById(R.id.poster);
            title=v.findViewById(R.id.title); overview=v.findViewById(R.id.overview); cta=v.findViewById(R.id.cta); }
    }
}
