package ir.palfin.flix.ui;
import android.os.Bundle; import android.os.Handler; import android.os.Looper;
import android.widget.TextView; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap; import java.util.Map;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.AuthCreateResponse; import ir.palfin.flix.model.AuthStatusResponse;
import retrofit2.Call; import retrofit2.Callback; import retrofit2.Response;
public class LoginActivity extends AppCompatActivity {
    private TextView pinView, status; private final Handler h=new Handler(Looper.getMainLooper());
    private String pin; private boolean done;
    private final Runnable poll=new Runnable(){ @Override public void run(){
        if(done||pin==null) return;
        ApiClient.api().authStatus("status", pin).enqueue(new Callback<AuthStatusResponse>(){
            @Override public void onResponse(Call<AuthStatusResponse> c, Response<AuthStatusResponse> r){
                AuthStatusResponse b=r.body();
                if(b==null||!b.ok){ if(b!=null && ("expired".equals(b.error)||"not_found".equals(b.error))){ status.setText("کد منقضی شد"); return; }
                    h.postDelayed(poll,1400); return; }
                if("approved".equals(b.status) && b.token!=null){
                    if(done) return; done=true;
                    String chat=b.user!=null?b.user.chat_id:""; String name=b.user!=null?b.user.name:"کاربر";
                    PalfinApp.get().session().save(b.token, chat, name);
                    status.setText("با موفقیت وارد شدید");
                    Toast.makeText(LoginActivity.this,"با موفقیت وارد شدید",Toast.LENGTH_SHORT).show();
                    finish(); return;
                }
                h.postDelayed(poll,1400);
            }
            @Override public void onFailure(Call<AuthStatusResponse> c, Throwable t){ h.postDelayed(poll,1800); }
        });
    }};
    @Override protected void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_login);
        pinView=findViewById(R.id.pin); status=findViewById(R.id.status);
        findViewById(R.id.btnBack).setOnClickListener(v->finish());
        Map<String,String> body=new HashMap<>(); body.put("action","create"); body.put("user_agent","PalfinFlix-Android/2.0");
        ApiClient.api().authCreate("create", body).enqueue(new Callback<AuthCreateResponse>(){
            @Override public void onResponse(Call<AuthCreateResponse> c, Response<AuthCreateResponse> r){
                AuthCreateResponse x=r.body();
                if(x==null||!x.ok||x.pin==null){ status.setText("خطا در ساخت کد"); return; }
                pin=x.pin; pinView.setText(pin); status.setText("در انتظار تأیید از مینی‌اپ...");
                h.postDelayed(poll,1200);
            }
            @Override public void onFailure(Call<AuthCreateResponse> c, Throwable t){ status.setText("خطای شبکه"); }
        });
    }
    @Override protected void onDestroy(){ super.onDestroy(); done=true; h.removeCallbacks(poll); }
}
