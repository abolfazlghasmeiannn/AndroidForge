package ir.palfin.flix.model;
import java.util.List;
public class TmdbListResponse { public java.util.List<TmdbMovie> results; }
