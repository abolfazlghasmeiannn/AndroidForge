package ir.palfin.flix.ui;
import android.content.Intent; import android.os.Bundle; import android.view.LayoutInflater;
import android.widget.LinearLayout; import android.widget.TextView; import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity; import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView; import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.gson.JsonArray; import com.google.gson.JsonObject;
import java.util.ArrayList; import java.util.HashMap; import java.util.List; import java.util.Map;
import ir.palfin.flix.PalfinApp; import ir.palfin.flix.R; import ir.palfin.flix.api.ApiClient;
import ir.palfin.flix.model.TmdbListResponse; import ir.palfin.flix.model.TmdbMovie; import ir.palfin.flix.util.NetworkUtil;
import retrofit2.Call; import retrofit2.Callback; import retrofit2.Response;
public class MainActivity extends AppCompatActivity {
    private LinearLayout sections; private SwipeRefreshLayout swipe; private HeroAdapter heroAdapter;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!NetworkUtil.isOnline(this)){ startActivity(new Intent(this, OfflineActivity.class)); finish(); return; }
        setContentView(R.layout.activity_main);
        sections=findViewById(R.id.sections); swipe=findViewById(R.id.swipe);
        swipe.setColorSchemeResources(R.color.red); swipe.setOnRefreshListener(this::reload);
        ViewPager2 hero=findViewById(R.id.hero);
        heroAdapter=new HeroAdapter(this::openDetail); hero.setAdapter(heroAdapter);
        findViewById(R.id.btnSearch).setOnClickListener(v-> startActivity(new Intent(this, SearchActivity.class)));
        BottomNavigationView nav=findViewById(R.id.bottomNav);
        nav.setOnItemSelectedListener(item->{
            int id=item.getItemId();
            if(id==R.id.nav_search){ startActivity(new Intent(this, SearchActivity.class)); return true; }
            if(id==R.id.nav_account){ startActivity(new Intent(this, ProfileActivity.class)); return true; }
            if(id==R.id.nav_sub){ startActivity(new Intent(this, SubscriptionActivity.class)); return true; }
            return true;
        });
        reload();
    }
    private void openDetail(TmdbMovie m){
        Intent i=new Intent(this, DetailActivity.class); i.putExtra("type", m.type()); i.putExtra("id", m.id); startActivity(i);
    }
    private void reload(){
        if(!NetworkUtil.isOnline(this)){ startActivity(new Intent(this, OfflineActivity.class)); return; }
        swipe.setRefreshing(true); sections.removeAllViews();
        loadHero(); loadRow("محبوب‌ترین‌ها","/movie/popular", new HashMap<>());
        Map<String,String> a=new HashMap<>(); a.put("with_genres","28"); a.put("sort_by","popularity.desc"); loadRow("اکشن","/discover/movie",a);
        Map<String,String> b=new HashMap<>(); b.put("with_genres","12"); b.put("sort_by","popularity.desc"); loadRow("ماجراجویی","/discover/movie",b);
        loadRow("سریال‌ها","/tv/popular", new HashMap<>());
        swipe.setRefreshing(false);
    }
    private void loadHero(){
        JsonObject s=PalfinApp.get().settings().get();
        List<String> imdbs=new ArrayList<>();
        if(s!=null && s.has("heroImdbIds") && s.get("heroImdbIds").isJsonArray()){
            JsonArray arr=s.getAsJsonArray("heroImdbIds");
            for(int i=0;i<arr.size();i++) imdbs.add(arr.get(i).getAsString());
        }
        if(imdbs.isEmpty()){
            ApiClient.api().tmdbList("tmdb","/movie/popular", new HashMap<>()).enqueue(new Callback<TmdbListResponse>(){
                @Override public void onResponse(Call<TmdbListResponse> c, Response<TmdbListResponse> r){
                    if(r.body()!=null && r.body().results!=null) heroAdapter.submit(r.body().results.subList(0, Math.min(5, r.body().results.size())));
                }
                @Override public void onFailure(Call<TmdbListResponse> c, Throwable t){}
            });
            return;
        }
        List<TmdbMovie> heroes=new ArrayList<>(); final int[] left={imdbs.size()};
        for(String imdb: imdbs){
            Map<String,String> p=new HashMap<>(); p.put("external_source","imdb_id");
            ApiClient.api().tmdbRaw("tmdb","/find/"+imdb, p).enqueue(new Callback<JsonObject>(){
                @Override public void onResponse(Call<JsonObject> call, Response<JsonObject> response){
                    try{
                        JsonObject body=response.body();
                        if(body!=null){
                            TmdbMovie m=null;
                            if(body.has("movie_results") && body.getAsJsonArray("movie_results").size()>0){
                                m=new com.google.gson.Gson().fromJson(body.getAsJsonArray("movie_results").get(0), TmdbMovie.class); m.mediaType="movie";
                            } else if(body.has("tv_results") && body.getAsJsonArray("tv_results").size()>0){
                                m=new com.google.gson.Gson().fromJson(body.getAsJsonArray("tv_results").get(0), TmdbMovie.class); m.mediaType="tv";
                            }
                            if(m!=null) heroes.add(m);
                        }
                    }catch(Exception ignored){}
                    left[0]--; if(left[0]<=0) heroAdapter.submit(heroes);
                }
                @Override public void onFailure(Call<JsonObject> call, Throwable t){ left[0]--; if(left[0]<=0) heroAdapter.submit(heroes); }
            });
        }
    }
    private void loadRow(String title, String path, Map<String,String> params){
        ApiClient.api().tmdbList("tmdb", path, params).enqueue(new Callback<TmdbListResponse>(){
            @Override public void onResponse(Call<TmdbListResponse> call, Response<TmdbListResponse> response){
                if(response.body()==null || response.body().results==null) return;
                LinearLayout block=(LinearLayout) LayoutInflater.from(MainActivity.this).inflate(R.layout.item_section, sections, false);
                ((TextView)block.findViewById(R.id.sectionTitle)).setText("▌ "+title);
                RecyclerView rv=block.findViewById(R.id.row);
                rv.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false));
                PosterAdapter ad=new PosterAdapter(MainActivity.this::openDetail); rv.setAdapter(ad); ad.submit(response.body().results);
                sections.addView(block);
            }
            @Override public void onFailure(Call<TmdbListResponse> call, Throwable t){
                Toast.makeText(MainActivity.this, R.string.error_network, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
