# PalfinFlix 2.0.0

Valid Android Gradle project (Java).

## Root files (required by AndroidForge)
- settings.gradle
- build.gradle
- gradle.properties
- gradle/wrapper/*
- app/build.gradle
- app/src/main/...

## Server
Upload palfin_android_api.php next to palfintvapk.php on:
https://palfin.ir/palfinapk/
