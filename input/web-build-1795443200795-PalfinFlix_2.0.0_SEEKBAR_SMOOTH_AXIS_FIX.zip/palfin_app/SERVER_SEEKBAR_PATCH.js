/**
 * Axis-aware seek-bar patch for the PalfinFlix HTML5 player.
 * App version also injects an equivalent fix from MainActivity.java.
 * Use these helpers in the site player if a permanent website-side fix is desired.
 */

function pfvGetSeekAxis(bar) {
  var vx = 1, vy = 0, node = bar;
  while (node && node !== document) {
    try {
      var tr = getComputedStyle(node).transform;
      if (tr && tr !== 'none') {
        var m = new DOMMatrix(tr);
        var nx = m.a * vx + m.c * vy;
        var ny = m.b * vx + m.d * vy;
        vx = nx; vy = ny;
      }
    } catch (e) {}
    node = node.parentElement;
  }
  return Math.abs(vy) > Math.abs(vx)
    ? { axis: 'y', sign: vy >= 0 ? 1 : -1 }
    : { axis: 'x', sign: vx >= 0 ? 1 : -1 };
}

function pfvSeekPercentFromXY(clientX, clientY, bar) {
  if (!bar) return 0;
  var rect = bar.getBoundingClientRect();
  var axis = pfvGetSeekAxis(bar);
  var length = axis.axis === 'x' ? rect.width : rect.height;
  var coordinate = axis.axis === 'x' ? clientX - rect.left : clientY - rect.top;
  if (!isFinite(length) || length <= 0) return 0;
  var pct = axis.sign > 0 ? coordinate / length : (length - coordinate) / length;
  return Math.max(0, Math.min(1, pct));
}

var _pfvSeekRaf = 0;
var _pfvSeekTarget = null;

function pfvSeekFromClientXY(clientX, clientY, commit) {
  if (!v) return;
  var bar = document.getElementById('pfvBar');
  if (!bar) return;
  var pct = pfvSeekPercentFromXY(clientX, clientY, bar);
  var duration = v.duration;
  if (!isFinite(duration) || duration <= 0) return;
  var time = pct * duration;
  _pfvSeekTarget = time;

  function paint() {
    var fill = document.getElementById('pfvFill');
    var knob = document.getElementById('pfvKnob');
    var current = document.getElementById('pfvCur');
    var remaining = document.getElementById('pfvRem');
    if (fill) fill.style.width = (pct * 100) + '%';
    if (knob) knob.style.left = (pct * 100) + '%';
    if (current) current.textContent = pfvFmt(time);
    if (remaining) remaining.textContent = '-' + pfvFmt(Math.max(0, duration - time));
  }

  if (_pfvSeekRaf) cancelAnimationFrame(_pfvSeekRaf);
  _pfvSeekRaf = requestAnimationFrame(function () {
    _pfvSeekRaf = 0;
    paint();
  });

  // WebView performance: commit actual seek only once on finger release.
  if (commit) {
    try { v.currentTime = time; } catch (e) {}
    _pfvSeekTarget = null;
  }
}
