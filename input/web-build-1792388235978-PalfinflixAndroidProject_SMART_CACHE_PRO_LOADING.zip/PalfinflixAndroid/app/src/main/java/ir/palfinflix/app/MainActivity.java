package ir.palfinflix.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.animation.Animation;
import android.view.animation.AlphaAnimation;

public class MainActivity extends Activity {
    private static final String HOME = "https://palfin.ir/palfinapk/palfintvapk.php";
    private FrameLayout root;
    private WebView web;
    private View offlineView;
    private View loadingView;
    private boolean pageFailed = false;
    private boolean initialLoadPending = true;
    private String lastPageUrl = "";
    private View returnLoadingView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,8,8));
        setContentView(root);
        buildWebView();
        // Start every app session with a fresh WebView cache. Resources can then be
        // cached during this session, without carrying cached images into next launch.
        web.clearCache(true);
        if (hasInternet()) { showLoading(); web.loadUrl(HOME); } else showOffline();
    }

    private void buildWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,8,8));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUserAgentString(s.getUserAgentString());
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, false); return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, true); return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                showNativeMessage(message, null, result, false, defaultValue); return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (shouldOpenExternally(uri)) {
                    openExternalLink(uri);
                    return true;
                }
                // Normal website pages remain inside the app.
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Compatibility with older Android System WebView versions.
                Uri uri = Uri.parse(url);
                if (shouldOpenExternally(uri)) {
                    openExternalLink(uri);
                    return true;
                }
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
                if (offlineView != null) { root.removeView(offlineView); offlineView = null; }
                boolean goingHome = isHomeUrl(url) && !isHomeUrl(lastPageUrl);
                if (initialLoadPending) {
                    // The cinematic splash is reserved for a fresh app launch.
                    initialLoadPending = false;
                } else if (goingHome) {
                    showReturnLoading();
                }
                lastPageUrl = url == null ? "" : url;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) { pageFailed = true; showOffline(); }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) showOffline();
            }
            @Override public void onPageCommitVisible(WebView view, String url) {
                // Hide the splash as soon as the first page content is ready to be drawn.
                if (initialLoadPending == false) hideLoading();
                hideReturnLoading();
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!pageFailed && offlineView != null) { root.removeView(offlineView); offlineView = null; }
                // Remove the blue WebView tap highlight without changing the website files.
                removeTapHighlight(view);
                // Fallback for pages/WebView versions where commit-visible is not called.
                hideLoading();
                hideReturnLoading();
                lastPageUrl = url == null ? lastPageUrl : url;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
    }


    private void removeTapHighlight(WebView view) {
        if (view == null) return;
        String css = "*{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;-webkit-touch-callout:none;}";
        String js = "(function(){try{var s=document.getElementById('palfinflix-no-tap-highlight');" +
                "if(!s){s=document.createElement('style');s.id='palfinflix-no-tap-highlight';" +
                "s.type='text/css';s.appendChild(document.createTextNode(" +
                "'" + css + "'));(document.head||document.documentElement).appendChild(s);}" +
                "}catch(e){}})();";
        if (android.os.Build.VERSION.SDK_INT >= 19) {
            view.evaluateJavascript(js, null);
        } else {
            view.loadUrl("javascript:" + js);
        }
    }

    private boolean shouldOpenExternally(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        // Only codexia.ir (and its www alias) must open outside the app.
        boolean codexiaLink = scheme.equals("http") || scheme.equals("https");
        codexiaLink = codexiaLink && (host.equals("codexia.ir") || host.equals("www.codexia.ir"));
        return codexiaLink || scheme.equals("tg") || scheme.equals("instagram")
                || host.equals("t.me") || host.endsWith(".t.me")
                || host.equals("telegram.me") || host.endsWith(".telegram.me")
                || host.equals("telegram.dog") || host.endsWith(".telegram.dog")
                || isInstagramWebLink(uri);
    }

    private void openExternalLink(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            // Prefer the official Telegram app for Telegram links when installed.
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
            if (scheme.equals("tg") || isTelegramWebLink(uri)) {
                intent.setPackage("org.telegram.messenger");
                try {
                    startActivity(intent);
                    return;
                } catch (android.content.ActivityNotFoundException ignored) {
                    intent.setPackage(null);
                }
            }
            // Prefer the official Instagram app for Instagram profile/post/reel links.
            if (isInstagramWebLink(uri) || scheme.equals("instagram")) {
                intent.setPackage("com.instagram.android");
                try {
                    startActivity(intent);
                    return;
                } catch (android.content.ActivityNotFoundException ignored) {
                    intent.setPackage(null);
                }
            }
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent browser = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(browser);
            } catch (Exception ignored) {
                new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("پالفین‌فلیکس")
                        .setMessage("برای باز کردن این لینک، تلگرام یا یک مرورگر نصب کنید.")
                        .setPositiveButton("باشه", null).show();
            }
        }
    }

    private boolean isTelegramWebLink(Uri uri) {
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        return host.equals("t.me") || host.endsWith(".t.me")
                || host.equals("telegram.me") || host.endsWith(".telegram.me")
                || host.equals("telegram.dog") || host.endsWith(".telegram.dog");
    }

    private boolean isInstagramWebLink(Uri uri) {
        if (uri == null) return false;
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        return host.equals("instagram.com") || host.endsWith(".instagram.com");
    }

    private boolean isHomeUrl(String value) {
        if (value == null || value.isEmpty()) return false;
        try {
            Uri u = Uri.parse(value);
            Uri h = Uri.parse(HOME);
            return h.getHost().equalsIgnoreCase(u.getHost() == null ? "" : u.getHost())
                    && (u.getPath() == null ? "" : u.getPath()).equals(h.getPath());
        } catch (Exception e) { return false; }
    }

    private void showReturnLoading() {
        runOnUiThread(() -> {
            if (offlineView != null || returnLoadingView != null) return;

            // Lightweight, polished return overlay. It never spins the brand mark and
            // cannot stay on screen for a long time if the site takes time to finish.
            LinearLayout shade = new LinearLayout(this);
            shade.setOrientation(LinearLayout.VERTICAL);
            shade.setGravity(Gravity.CENTER);
            shade.setPadding(dp(30), dp(24), dp(30), dp(24));
            shade.setBackgroundColor(0xE9080808);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(24), dp(25), dp(24), dp(23));
            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setColor(0xFF151515);
            cardBg.setCornerRadius(dp(18));
            cardBg.setStroke(dp(1), 0xFF352025);
            card.setBackground(cardBg);
            shade.addView(card, new LinearLayout.LayoutParams(-1, -2));

            TextView eyebrow = new TextView(this);
            eyebrow.setText("PALFINFLIX  /  HOME");
            eyebrow.setTextColor(0xFFFF435B);
            eyebrow.setTextSize(10);
            eyebrow.setLetterSpacing(0.14f);
            eyebrow.setGravity(Gravity.CENTER);
            card.addView(eyebrow, new LinearLayout.LayoutParams(-1, -2));

            TextView title = new TextView(this);
            title.setText("در حال بازگشت به صفحه اصلی");
            title.setTextColor(Color.WHITE);
            title.setTextSize(18);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
            titleParams.topMargin = dp(11);
            card.addView(title, titleParams);

            TextView subtitle = new TextView(this);
            subtitle.setText("در حال آماده‌سازی صفحه خانه...");
            subtitle.setTextColor(0xFFB8B8B8);
            subtitle.setTextSize(12);
            subtitle.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
            subParams.topMargin = dp(7);
            subParams.bottomMargin = dp(20);
            card.addView(subtitle, subParams);

            FrameLayout track = new FrameLayout(this);
            GradientDrawable trackBg = new GradientDrawable();
            trackBg.setColor(0xFF343434);
            trackBg.setCornerRadius(dp(4));
            track.setBackground(trackBg);
            track.setClipToOutline(true);
            card.addView(track, new LinearLayout.LayoutParams(-1, dp(5)));

            View movingBar = new View(this);
            GradientDrawable barBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00FF1744, 0xFFFF1744, 0xFFFF8190, 0xFFFF1744, 0x00FF1744});
            barBg.setCornerRadius(dp(4));
            movingBar.setBackground(barBg);
            FrameLayout.LayoutParams movingParams = new FrameLayout.LayoutParams(dp(85), -1, Gravity.LEFT);
            track.addView(movingBar, movingParams);
            movingBar.post(() -> {
                if (returnLoadingView != shade || track.getWidth() <= 0) return;
                android.animation.ObjectAnimator barAnimator = android.animation.ObjectAnimator.ofFloat(
                        movingBar, "translationX", -dp(90), track.getWidth() + dp(5));
                barAnimator.setDuration(850);
                barAnimator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                barAnimator.setInterpolator(new android.view.animation.LinearInterpolator());
                barAnimator.start();
                movingBar.setTag(barAnimator);
            });

            returnLoadingView = shade;
            root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
            shade.setAlpha(0f);
            shade.animate().alpha(1f).setDuration(130).start();

            // Safety timeout: returning home must not leave a full-screen loader
            // blocking the user while images or other secondary assets load.
            shade.postDelayed(() -> {
                if (returnLoadingView == shade) hideReturnLoading();
            }, 700);
        });
    }

    private void hideReturnLoading() {
        runOnUiThread(() -> {
            if (returnLoadingView == null) return;
            View old = returnLoadingView;
            returnLoadingView = null;
            // Stop the moving progress segment.
            if (old instanceof ViewGroup) {
                ViewGroup outer = (ViewGroup) old;
                if (outer.getChildCount() > 0 && outer.getChildAt(0) instanceof ViewGroup) {
                    ViewGroup card = (ViewGroup) outer.getChildAt(0);
                    // Children: eyebrow, title, subtitle, progress track.
                    if (card.getChildCount() > 3 && card.getChildAt(3) instanceof ViewGroup) {
                        ViewGroup track = (ViewGroup) card.getChildAt(3);
                        if (track.getChildCount() > 0) {
                            Object tag = track.getChildAt(0).getTag();
                            if (tag instanceof android.animation.Animator) ((android.animation.Animator) tag).cancel();
                        }
                    }
                }
            }
            old.animate().alpha(0f).setDuration(140).withEndAction(() -> {
                if (old.getParent() == root) root.removeView(old);
            }).start();
        });
    }

    private void showLoading() {
        runOnUiThread(() -> {
            if (offlineView != null || loadingView != null) return;

            FrameLayout splash = new FrameLayout(this);
            splash.setBackgroundColor(Color.rgb(5, 4, 7));

            // Full-screen user supplied cinematic artwork.
            ImageView backdrop = new ImageView(this);
            int splashId = getResources().getIdentifier("palfinflix_splash", "drawable", getPackageName());
            if (splashId != 0) backdrop.setImageResource(splashId);
            backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
            splash.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));

            // Dark tint keeps the loading message and bar readable.
            View shade = new View(this);
            shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x33000000, 0x55000000, 0xCC000000, 0xEE000000}));
            splash.addView(shade, new FrameLayout.LayoutParams(-1, -1));

            LinearLayout bottom = new LinearLayout(this);
            bottom.setOrientation(LinearLayout.VERTICAL);
            bottom.setGravity(Gravity.CENTER);
            bottom.setPadding(34, 18, 34, 44);
            FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(
                    -1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            splash.addView(bottom, bottomParams);

            TextView title = new TextView(this);
            title.setText("پالفین‌فلیکس");
            title.setTextColor(Color.WHITE);
            title.setTextSize(25);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            bottom.addView(title, new LinearLayout.LayoutParams(-1, -2));

            TextView caption = new TextView(this);
            caption.setText("در حال آماده‌سازی دنیای فیلم و سریال...");
            caption.setTextColor(0xFFE5E5E5);
            caption.setTextSize(13);
            caption.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams captionParams = new LinearLayout.LayoutParams(-1, -2);
            captionParams.topMargin = 8;
            captionParams.bottomMargin = 22;
            bottom.addView(caption, captionParams);

            // Slim cinematic track with a glowing red segment that travels across it.
            FrameLayout track = new FrameLayout(this);
            GradientDrawable trackBg = new GradientDrawable();
            trackBg.setColor(0x66FFFFFF);
            trackBg.setCornerRadius(dp(5));
            track.setBackground(trackBg);
            track.setClipToOutline(true);
            LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(dp(250), dp(5));
            bottom.addView(track, trackParams);

            View glow = new View(this);
            GradientDrawable glowBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00FF1744, 0xFFFF1744, 0xFFFF6B81, 0xFFFF1744, 0x00FF1744});
            glowBg.setCornerRadius(dp(5));
            glow.setBackground(glowBg);
            FrameLayout.LayoutParams glowParams = new FrameLayout.LayoutParams(dp(95), -1, Gravity.LEFT);
            track.addView(glow, glowParams);
            glow.post(() -> {
                if (loadingView != splash) return;
                android.animation.ObjectAnimator animator = android.animation.ObjectAnimator.ofFloat(
                        glow, "translationX", -dp(100), track.getWidth() + dp(10));
                animator.setDuration(1150);
                animator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                animator.start();
                glow.setTag(animator);
            });

            TextView status = new TextView(this);
            status.setText("PALFINFLIX  •  LOADING");
            status.setTextColor(0xFFBBBBBB);
            status.setTextSize(10);
            status.setLetterSpacing(0.12f);
            status.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
            statusParams.topMargin = 13;
            bottom.addView(status, statusParams);

            loadingView = splash;
            root.addView(loadingView, new FrameLayout.LayoutParams(-1, -1));
            splash.setAlpha(0f);
            splash.animate().alpha(1f).setDuration(220).start();
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideLoading() {
        runOnUiThread(() -> {
            if (loadingView == null) return;
            View old = loadingView; loadingView = null;
            old.animate().alpha(0f).setDuration(220).withEndAction(() -> root.removeView(old)).start();
        });
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm) {
        showNativeMessage(message, jsResult, promptResult, confirm, "");
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm, String defaultValue) {
        runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK);
            builder.setTitle("پالفین‌فلیکس");
            builder.setMessage(message == null ? "" : message);
            if (promptResult != null) {
                EditText input = new EditText(this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY);
                builder.setView(input);
                builder.setPositiveButton("تأیید", (d,w) -> promptResult.confirm(input.getText().toString()));
                builder.setNegativeButton("لغو", (d,w) -> promptResult.cancel());
                builder.setOnCancelListener(d -> promptResult.cancel());
            } else if (confirm) {
                builder.setPositiveButton("تأیید", (d,w) -> jsResult.confirm());
                builder.setNegativeButton("لغو", (d,w) -> jsResult.cancel());
                builder.setOnCancelListener(d -> jsResult.cancel());
            } else {
                builder.setPositiveButton("متوجه شدم", (d,w) -> jsResult.confirm());
                builder.setOnCancelListener(d -> jsResult.confirm());
            }
            try { builder.create().show(); }
            catch (Exception e) { if (jsResult != null) jsResult.cancel(); if (promptResult != null) promptResult.cancel(); }
        });
    }

    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return true; }
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void showOffline() {
        runOnUiThread(() -> {
            hideLoading();
            if (offlineView != null) root.removeView(offlineView);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setPadding(30,30,30,30);
            page.setBackgroundColor(Color.rgb(8,8,8));

            TextView brand = new TextView(this);
            brand.setText("PALFINFLIX"); brand.setTextColor(Color.rgb(229,9,20));
            brand.setTextSize(27); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            brand.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.bottomMargin=48;
            page.addView(brand,bp);

            FrameLayout iconBox = new FrameLayout(this);
            iconBox.setBackground(rounded(Color.rgb(28,28,28), 100));
            LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(190,190); ibp.bottomMargin=28;
            page.addView(iconBox,ibp);
            TextView wifi = new TextView(this);
            wifi.setText("⌁"); wifi.setTextColor(Color.rgb(229,9,20)); wifi.setTextSize(74);
            wifi.setGravity(Gravity.CENTER);
            iconBox.addView(wifi,new FrameLayout.LayoutParams(-1,-1));
            AlphaAnimation pulse = new AlphaAnimation(0.35f,1f); pulse.setDuration(900); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE); wifi.startAnimation(pulse);

            TextView title = new TextView(this);
            title.setText("اتصال برقرار نشد"); title.setTextColor(Color.WHITE); title.setTextSize(21);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
            page.addView(title);
            TextView desc = new TextView(this);
            desc.setText("اینترنت خود را چک کنید"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(16);
            desc.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=10; dp.bottomMargin=28;
            page.addView(desc,dp);
            TextView retry = new TextView(this);
            retry.setText("تلاش مجدد"); retry.setTextColor(Color.WHITE); retry.setTextSize(16); retry.setGravity(Gravity.CENTER);
            retry.setPadding(42,16,42,16); retry.setBackground(rounded(Color.rgb(229,9,20),50));
            retry.setOnClickListener(v -> { if (hasInternet()) { if (offlineView != null) root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else { wifi.clearAnimation(); wifi.startAnimation(pulse); } });
            page.addView(retry);
            offlineView = page;
            root.addView(offlineView,new FrameLayout.LayoutParams(-1,-1));
        });
    }

    @Override protected void onDestroy() {
        // Keep the image/resource cache only for the lifetime of this app session.
        // The next launch starts clean and receives fresh page data.
        if (web != null) {
            try { web.stopLoading(); } catch (Exception ignored) { }
            try { web.clearCache(true); } catch (Exception ignored) { }
            try { web.clearHistory(); } catch (Exception ignored) { }
            try { web.destroy(); } catch (Exception ignored) { }
            web = null;
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (offlineView != null) { if (hasInternet()) { root.removeView(offlineView); offlineView=null; web.loadUrl(HOME); } else super.onBackPressed(); }
        else if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
