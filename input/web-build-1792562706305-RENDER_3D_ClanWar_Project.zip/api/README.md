# RENDER online clan-war backend (PHP + MySQL)

This is a server-side starter for persistent accounts, clans and clan wars. It is not live until deployed to a PHP 8+ host with MySQL and HTTPS.

## Setup
1. Create a MySQL database and import `sql/schema.sql`.
2. Set `RENDER_DB_HOST`, `RENDER_DB_NAME`, `RENDER_DB_USER`, `RENDER_DB_PASS` on the host, or edit `config.php` (never put production secrets in the APK).
3. Upload the entire `api/` folder to your host. Example base URL: `https://your-domain.example/api`.
4. Restrict CORS in `common.php` to your actual site/app origin, enable HTTPS, rate limiting, backups and monitoring.
5. Register/login with `POST /auth.php` JSON `{"action":"register","username":"player_01","password":"at-least-8-chars"}` or `{"action":"login",...}`. Copy the returned token into the RENDER War Room.
6. Create a clan with `POST /clan.php` JSON `{"action":"create","name":"Obsidian Wolves","tag":"OBW"}`. Clan listing: `POST /clan.php` with `{"action":"list"}`. Join: `{"action":"join","clan_id":2}`.
7. Start a war as a clan leader/elder: `POST /war.php` with `{"action":"start","opponent_clan_id":2}`. View status/scores with `GET /war.php`. Submit a server-calculated attack with `POST /attack.php` and JSON `{"troops":{"vanguard":5,"ranger":4,"golem":1}}`.

## Important
- All endpoints expect `Authorization: Bearer <token>` except no endpoint is intended to be public without authentication. `clan.php` listing currently also requires authentication.
- Each player gets up to two attacks per war. Attack stars/destruction are calculated server-side, not accepted from the client.
- This is a functional starter, not a production audited service. Add account recovery, token expiry/rotation, anti-cheat review, moderation, privacy policy, rate limits and more robust matchmaking before a public launch.
- The Three.js battle scene is client-rendered 3D and currently uses a CDN; an internet connection is required for the Three.js library. It is a visual tactical scene, not a full real-time 3D multiplayer combat simulation.
