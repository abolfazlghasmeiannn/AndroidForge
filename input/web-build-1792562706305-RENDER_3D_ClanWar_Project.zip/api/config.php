<?php
// RENDER server configuration template. Keep secrets outside the public web root.
return [
    'db_host' => getenv('RENDER_DB_HOST') ?: '127.0.0.1',
    'db_name' => getenv('RENDER_DB_NAME') ?: 'render_game',
    'db_user' => getenv('RENDER_DB_USER') ?: 'render_user',
    'db_pass' => getenv('RENDER_DB_PASS') ?: '',
];
