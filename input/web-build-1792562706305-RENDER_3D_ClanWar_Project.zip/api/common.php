<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // Restrict to your app/site origin for production.
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
function out(array $data, int $status=200): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function body(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function db(): PDO { static $pdo=null; if($pdo) return $pdo; $c=require __DIR__.'/config.php'; $dsn='mysql:host='.$c['db_host'].';dbname='.$c['db_name'].';charset=utf8mb4'; try{$pdo=new PDO($dsn,$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}catch(Throwable $e){out(['error'=>'Database unavailable. Configure api/config.php or environment variables.'],503);} return $pdo; }
function user(): array { $h=$_SERVER['HTTP_AUTHORIZATION']??''; if(!preg_match('/^Bearer\s+([a-f0-9]{64})$/i',$h,$m))out(['error'=>'Sign in first; missing bearer token.'],401); $q=db()->prepare('SELECT id,username FROM users WHERE token_hash=?');$q->execute([hash('sha256',$m[1])]);$u=$q->fetch();if(!$u)out(['error'=>'Invalid access token.'],401);return $u; }
function membership(int $uid): array { $q=db()->prepare('SELECT cm.clan_id,cm.role,c.name,c.tag FROM clan_members cm JOIN clans c ON c.id=cm.clan_id WHERE cm.user_id=?');$q->execute([$uid]);$r=$q->fetch();if(!$r)out(['error'=>'Join a clan first.'],403);return $r; }
