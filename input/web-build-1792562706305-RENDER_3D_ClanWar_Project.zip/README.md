# RENDER — AndroidForge project

Mobile-first HTML/CSS/JavaScript strategy game prototype with a Three.js 3D battle arena and an optional PHP/MySQL online clan-war backend.

## Open / package
- Open `index.html` in a modern browser for the local village and battle prototype.
- AndroidForge should package the web files into an Android WebView app. Allow internet access: Three.js is loaded from jsDelivr CDN in this build.
- The battle scene is real-time rendered 3D geometry with lighting, shadows, castles, towers, trees and animated troops. The village screen remains the original 2D/isometric prototype.

## Online clan wars
The backend is not live just by installing the APK. Deploy `/api` to a PHP 8+ host, configure MySQL using `api/sql/schema.sql`, and follow `api/README.md`. In the in-game Clan War Room, enter the HTTPS API base URL, register/sign in, create a clan or join by ID, then start a war using the opponent clan ID. Each player can submit up to two server-scored attacks per war.

This is a development build, not a production-certified online game. Clan war persistence works only when the backend is deployed and configured. The 3D combat is a client-side visualization; attacks and war scores are stored/calculated on the server, but this is not full real-time multiplayer character control. Review security, CORS, rate limits, privacy and anti-cheat before public release.
