# پروژه دسکتاپ PalfinFlix (Windows / Linux / macOS)

این پروژه یک برنامه دسکتاپ مستقل با Electron است و نسخه مخصوص دسکتاپ سایت را در پنجره برنامه نمایش می‌دهد.

آدرس سایت داخل برنامه: `https://palfinflix.ir/palfinapk/palfintvvin.php`

## امکانات
- پنجره آغازین 1180×760 و وسط صفحه؛ در شروع تمام‌صفحه نیست.
- حداقل اندازه پنجره 900×600.
- نوار عنوان اختصاصی با دکمه‌های کمینه‌سازی، بزرگ‌کردن/بازگرداندن و بستن.
- ظاهر تیره با رنگ قرمز پالفین‌فلیکس.
- نمایش مستقیم صفحه دسکتاپ سایت در پنجره Electron؛ فایل PHP سایت تغییر نمی‌کند.
- تنظیمات امنیتی پایه Electron: contextIsolation، sandbox و غیرفعال بودن nodeIntegration.

## ساخت با GitHub Actions
فایل گردش‌کار در مسیر `.github/workflows/build-desktop.yml` قرار دارد.

1. محتویات همین پوشه پروژه را در ریشه مخزن GitHub قرار دهید؛ پوشه `PalfinFlix-Desktop` را به‌صورت یک پوشه تو در توی اضافی نگه ندارید.
2. تغییرات را در شاخه `main` ذخیره و Push کنید.
3. در GitHub وارد تب **Actions** شوید.
4. گردش‌کار **Build Desktop (Windows + Linux)** را انتخاب کنید و روی **Run workflow** بزنید.
5. پس از موفقیت، در بخش **Artifacts** فایل‌های Windows و Linux قابل دریافت هستند.

این گردش‌کار از Node.js 22 و نسخه‌های جدید اکشن‌های checkout، setup-node و upload-artifact استفاده می‌کند.

## ساخت محلی
Node.js نسخه 22 را نصب کنید و در ریشه پروژه اجرا کنید:

```bash
npm install
npm start
```

ساخت نصاب ویندوز: `npm run dist:win`

ساخت بسته‌های لینوکس: `npm run dist:linux`

ساخت macOS باید روی سیستم macOS انجام شود: `npm run dist:mac`

خروجی‌ها در پوشه `release` ذخیره می‌شوند.

## نکته مهم درباره AndroidForge
این پروژه Electron دسکتاپ است و ساختار Android/Gradle ندارد. AndroidForge که برای ساخت APK اندروید است، نمی‌تواند از این پروژه فایل نصاب Windows یا macOS بسازد. برای خروجی دسکتاپ از GitHub Actions بالا یا محیط Node.js و Electron Builder استفاده کنید.

## وضعیت تست
ساخت نهایی exe، AppImage، deb و dmg در این محیط اجرا نشده است. اگر GitHub Actions خطا داد، متن کامل مرحله قرمز را ارسال کنید تا بر اساس خطای واقعی اصلاح شود.
