# RENDER Football — AndroidForge-ready project

A self-contained Android WebView football game prototype with a polished dark mobile UI, animated night-stadium presentation, stylized player sprites, touch controls, match clock and score, local club selection, squad list and basic substitutions.

## Build APK using AndroidForge
1. Open https://professional-x.github.io/AndroidForge/ in your phone browser.
2. Connect a GitHub repository/fork and create a GitHub token with the permissions requested by AndroidForge. Keep the token private; never send it to anyone.
3. Upload this ZIP as the Android source project.
4. Choose Android and the `auto` or `debug` build variant, then start the build.
5. When GitHub Actions finishes, open the run and download the APK artifact ZIP, then extract and install the APK. Android may ask you to allow installs from your browser/files app.

## What's included
- Landscape Android app with offline local HTML5 match screen.
- 13 selectable clubs and club badges loaded from ESPN's public image CDN (internet required for badges; fallback initials are shown if unavailable).
- Match length selection, club selection, score, match timer, pause/full-time screens.
- Touch movement, pass, shoot, tackle/press, player switch, Bluetooth gamepad API attempt.
- Starting XI and substitute lists with basic squad swaps.
- JavaScript is bundled locally; the match screen itself can run offline.

## Important limitations
This is a polished 2D/2.5D-style prototype, not a full 3D football simulation and not equivalent to EA SPORTS FC Mobile/eFootball. Player movement, opponent behaviour, scoring and substitutions are simplified. There is no online multiplayer, licensed commentary, full football rules, realistic 3D player models, live roster feed, or verified current-season roster data. Some names/club marks may be outdated or subject to rights restrictions.

The project files were checked for ZIP integrity and JavaScript syntax. An actual APK build and on-device test have not been performed here; AndroidForge must complete the build and the APK should then be tested on your phone.
