# RENDER Football — AndroidForge package

This is a lightweight, offline-first HTML5/JavaScript football prototype wrapped in an Android WebView. It is intended to be built as an APK using a compatible cloud Android build workflow such as AndroidForge/GitHub Actions.

## Included in this revision
- Improved stadium/grass rendering, crowd-like stands and pitch-side branding.
- Native Android controller key forwarding from Bluetooth/USB gamepads to the HTML game, plus browser Gamepad API fallback.
- Controller mapping: D-pad = movement; A = pass; B = shoot; X/L1 = switch player; Y = tackle; Start = pause. Controller button layouts can vary by device.
- Local two-player mode: select `2 Players · same device` before kickoff; first controller controls home, second controller controls away. The two-player mode depends on Android reporting distinct controller device IDs or Web Gamepad indices.
- Procedural sound effects for kick, whistle, goal, plus a generated low-volume ambient bed. These are synthesized effects, not recorded stadium commentary.
- Basic match restarts for throw-ins, goal-line restarts, goals, and a simplified foul/free-kick event.

## Important limitations
This is **not** a full simulation of association football and is not comparable to FC Mobile. It uses 2D Canvas player drawings with depth cues, not 3D player models. Offside, penalties, cards, substitutions during live play, full goalkeeper logic, realistic physics, commentary, online multiplayer, and complete referee/rules logic are not implemented. Club rosters are manually curated examples and may be outdated. Crests are loaded from an external URL and need internet access; fallback initials are shown if they fail.

## Build
1. Upload this project ZIP to your compatible AndroidForge workflow.
2. Build a debug APK using its documented setup.
3. Install and test on the actual Android phone, especially controller compatibility. Gamepad key mappings differ between Android devices and controllers.

The source package and JavaScript syntax are checked, but an APK has not been built or device-tested in this environment. No guarantee of a successful build is made until AndroidForge completes its build.
