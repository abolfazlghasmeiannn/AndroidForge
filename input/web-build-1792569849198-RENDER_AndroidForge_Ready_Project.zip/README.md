# RENDER Android project (Gradle WebView wrapper)

This is an actual Android Gradle project wrapping the RENDER HTML/CSS/JavaScript game in a native Android WebView. It fixes the reported AndroidForge error where the uploaded workspace had no `settings.gradle` or `build.gradle`.

## Project layout
- `settings.gradle` — Gradle root and `:app` module
- `build.gradle` — Android Gradle Plugin declaration
- `app/build.gradle` — Android application configuration
- `app/src/main/AndroidManifest.xml` — launcher activity and Internet permission
- `app/src/main/assets/www/` — game web assets

## Build
Use JDK 17 and Android SDK platform 35. From this directory run:

```bash
gradle assembleDebug
```

Expected debug APK output:
`app/build/outputs/apk/debug/app-debug.apk`

If using AndroidForge, upload this ZIP as a **Gradle Android project** and ensure the builder works from the archive root (the directory containing `settings.gradle`). Do not upload the previous web-only ZIP.

## Important notes
- The game loads Three.js from jsDelivr, so internet access is needed for the 3D arena. If a CDN is blocked, the 3D view may not load.
- Clan war PHP endpoints are not bundled as a running server. Deploy `/api` to a PHP 8+ host with MySQL and configure it before expecting real online clan wars.
- This archive has not been compiled on a remote Android build service or tested on a physical device here. It provides the missing Android/Gradle project structure; build-service configuration and SDK availability can still affect compilation.
