package ir.palfinflix.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.widget.Toast;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.view.animation.Animation;
import android.view.animation.AlphaAnimation;
import android.view.Window;
import android.view.WindowManager;
import android.content.res.ColorStateList;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String HOME = "https://palfin.ir/palfinapk/palfintvapk.php";
    private static final String UPDATE_API = "https://codexia.ir/app/check-update.php";
    private final ExecutorService updateExecutor = Executors.newSingleThreadExecutor();
    private final Handler updateHandler = new Handler(Looper.getMainLooper());
    private boolean updateDismissedThisSession = false;
    private Dialog updateDialog;
    private Dialog downloadDialog;
    private long activeDownloadId = -1L;
    private boolean downloadProgressRunning = false;
    private FrameLayout root;
    private WebView web;
    private View offlineView;
    private View loadingView;
    private boolean pageFailed = false;
    private boolean initialLoadPending = true;
    private String lastPageUrl = "";
    private View returnLoadingView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,8,8));
        // Keep app content inside the usable area on phones with different status/navigation bars.
        // This is especially important on Android 15+, where edge-to-edge is enforced for target SDK 35.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(left, top, right, bottom);
            return insets;
        });
        setContentView(root);
        buildWebView();
        if (hasInternet()) { showLoading(); web.loadUrl(HOME); } else showOffline();
        // The update check runs quietly in the background; the website continues loading normally.
        checkForUpdates();
    }

    private void buildWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8,8,8));
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUserAgentString(s.getUserAgentString());
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, false); return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                showNativeMessage(message, result, null, true); return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                showNativeMessage(message, null, result, false, defaultValue); return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (shouldOpenExternally(uri)) {
                    openExternalLink(uri);
                    return true;
                }
                // Normal website pages remain inside the app.
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Compatibility with older Android System WebView versions.
                Uri uri = Uri.parse(url);
                if (shouldOpenExternally(uri)) {
                    openExternalLink(uri);
                    return true;
                }
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
                // A new navigation is underway; reveal the WebView only while it is loading.
                view.setVisibility(View.VISIBLE);
                if (offlineView != null) { root.removeView(offlineView); offlineView = null; }
                boolean goingHome = isHomeUrl(url) && !isHomeUrl(lastPageUrl);
                if (initialLoadPending) {
                    // The cinematic splash is reserved for a fresh app launch.
                    initialLoadPending = false;
                } else if (goingHome) {
                    showReturnLoading();
                }
                lastPageUrl = url == null ? "" : url;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageFailed = true;
                    showOffline();
                }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    pageFailed = true;
                    showOffline();
                }
            }
            @Override public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler, android.net.http.SslError error) {
                // Never expose WebView's built-in network/security error page.
                handler.cancel();
                pageFailed = true;
                showOffline();
            }
            @Override public void onPageCommitVisible(WebView view, String url) {
                // Hide the splash as soon as the first page content is ready to be drawn.
                if (initialLoadPending == false) hideLoading();
                hideReturnLoading();
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!pageFailed && offlineView != null) { root.removeView(offlineView); offlineView = null; }
                if (pageFailed) {
                    // Keep any Chromium/WebView error document completely behind the native offline screen.
                    view.setVisibility(View.INVISIBLE);
                    return;
                }
                // Remove the blue WebView tap highlight without changing the website files.
                removeTapHighlight(view);
                // Fallback for pages/WebView versions where commit-visible is not called.
                hideLoading();
                hideReturnLoading();
                lastPageUrl = url == null ? lastPageUrl : url;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
    }


    private void removeTapHighlight(WebView view) {
        if (view == null) return;
        String css = "*{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;-webkit-touch-callout:none;}";
        String js = "(function(){try{var s=document.getElementById('palfinflix-no-tap-highlight');" +
                "if(!s){s=document.createElement('style');s.id='palfinflix-no-tap-highlight';" +
                "s.type='text/css';s.appendChild(document.createTextNode(" +
                "'" + css + "'));(document.head||document.documentElement).appendChild(s);}" +
                "}catch(e){}})();";
        if (android.os.Build.VERSION.SDK_INT >= 19) {
            view.evaluateJavascript(js, null);
        } else {
            view.loadUrl("javascript:" + js);
        }
    }

    private boolean shouldOpenExternally(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        // Only codexia.ir (and its www alias) must open outside the app.
        boolean codexiaLink = scheme.equals("http") || scheme.equals("https");
        codexiaLink = codexiaLink && (host.equals("codexia.ir") || host.equals("www.codexia.ir"));
        return codexiaLink || scheme.equals("tg") || scheme.equals("instagram")
                || host.equals("t.me") || host.endsWith(".t.me")
                || host.equals("telegram.me") || host.endsWith(".telegram.me")
                || host.equals("telegram.dog") || host.endsWith(".telegram.dog")
                || isInstagramWebLink(uri);
    }

    private void openExternalLink(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            // Prefer the official Telegram app for Telegram links when installed.
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
            if (scheme.equals("tg") || isTelegramWebLink(uri)) {
                intent.setPackage("org.telegram.messenger");
                try {
                    startActivity(intent);
                    return;
                } catch (android.content.ActivityNotFoundException ignored) {
                    intent.setPackage(null);
                }
            }
            // Prefer the official Instagram app for Instagram profile/post/reel links.
            if (isInstagramWebLink(uri) || scheme.equals("instagram")) {
                intent.setPackage("com.instagram.android");
                try {
                    startActivity(intent);
                    return;
                } catch (android.content.ActivityNotFoundException ignored) {
                    intent.setPackage(null);
                }
            }
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent browser = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(browser);
            } catch (Exception ignored) {
                new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("پالفین‌فلیکس")
                        .setMessage("برای باز کردن این لینک، تلگرام یا یک مرورگر نصب کنید.")
                        .setPositiveButton("باشه", null).show();
            }
        }
    }

    private boolean isTelegramWebLink(Uri uri) {
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        return host.equals("t.me") || host.endsWith(".t.me")
                || host.equals("telegram.me") || host.endsWith(".telegram.me")
                || host.equals("telegram.dog") || host.endsWith(".telegram.dog");
    }

    private boolean isInstagramWebLink(Uri uri) {
        if (uri == null) return false;
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(java.util.Locale.ROOT);
        return host.equals("instagram.com") || host.endsWith(".instagram.com");
    }

    private boolean isHomeUrl(String value) {
        if (value == null || value.isEmpty()) return false;
        try {
            Uri u = Uri.parse(value);
            Uri h = Uri.parse(HOME);
            return h.getHost().equalsIgnoreCase(u.getHost() == null ? "" : u.getHost())
                    && (u.getPath() == null ? "" : u.getPath()).equals(h.getPath());
        } catch (Exception e) { return false; }
    }

    /** Minimal black-and-red cinema clapperboard. Its top slate moves once, then rests. */
    private class ClapperboardView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float flapAngle = -7f;
        private boolean introPlayed = false;
        ClapperboardView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void playIntro() {
            if (introPlayed) return;
            introPlayed = true;
            android.animation.ObjectAnimator a = android.animation.ObjectAnimator.ofFloat(this, "flapAngle", -7f, 0f, -2f, 0f);
            a.setDuration(520);
            a.setInterpolator(new android.view.animation.DecelerateInterpolator());
            a.start();
        }
        public void setFlapAngle(float angle) { flapAngle = angle; invalidate(); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w=getWidth(), h=getHeight();
            float left=w*.08f, right=w*.92f, top=h*.29f, bottom=h*.91f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFF101014);
            canvas.drawRoundRect(new RectF(left,top,right,bottom), dp(7),dp(7),paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth((1.4f * getResources().getDisplayMetrics().density)); paint.setColor(0xFFFF1744);
            canvas.drawRoundRect(new RectF(left,top,right,bottom), dp(7),dp(7),paint);
            paint.setStyle(Paint.Style.FILL); paint.setColor(0xFF29292F);
            canvas.drawRoundRect(new RectF(left+dp(5),top+dp(6),right-dp(5),bottom-dp(6)),dp(3),dp(3),paint);
            // Tiny red play mark in the body.
            Path play=new Path(); play.moveTo(w*.43f,h*.48f); play.lineTo(w*.43f,h*.70f); play.lineTo(w*.61f,h*.59f); play.close();
            paint.setColor(0xFFFF1744); canvas.drawPath(play,paint);
            // Hinged striped top slate; rotate only during the brief intro.
            canvas.save();
            canvas.rotate(flapAngle, left+dp(3), top+dp(2));
            RectF slate=new RectF(left, h*.08f, right, h*.34f);
            paint.setColor(0xFF202026); paint.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(slate,dp(4),dp(4),paint);
            canvas.save(); canvas.clipRect(slate);
            paint.setColor(0xFFF0F0F2);
            for(int i=0;i<5;i++) {
                float x=left+dp(3)+i*(right-left-dp(12))/5f;
                Path stripe=new Path(); stripe.moveTo(x,h*.08f); stripe.lineTo(x+dp(7),h*.08f); stripe.lineTo(x-dp(2),h*.34f); stripe.lineTo(x-dp(9),h*.34f); stripe.close();
                canvas.drawPath(stripe,paint);
            }
            canvas.restore();
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth((1.2f * getResources().getDisplayMetrics().density)); paint.setColor(0xFFFF1744);
            canvas.drawRoundRect(slate,dp(4),dp(4),paint);
            canvas.restore();
        }
    }

    private void showReturnLoading() {
        runOnUiThread(() -> {
            if (offlineView != null || returnLoadingView != null) return;

            // Dim the existing page slightly; keep it visible behind a compact modal card.
            FrameLayout overlay = new FrameLayout(this);
            overlay.setBackgroundColor(0x99000000);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(24), dp(24), dp(24), dp(24));
            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setColor(0xFF19191D);
            cardBg.setCornerRadius(dp(22));
            cardBg.setStroke(dp(1), 0x66FF1744);
            card.setBackground(cardBg);
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                card.setElevation(dp(12));
            }

            // Replace the app icon with a compact cinematic clapperboard graphic.
            ClapperboardView clapperboard = new ClapperboardView(this);
            LinearLayout.LayoutParams clapperParams = new LinearLayout.LayoutParams(dp(76), dp(58));
            clapperParams.bottomMargin = dp(16);
            card.addView(clapperboard, clapperParams);
            clapperboard.post(clapperboard::playIntro);

            TextView title = new TextView(this);
            title.setText("در حال بازگشت به صفحه اصلی");
            title.setTextColor(Color.WHITE);
            title.setTextSize(17);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            title.setIncludeFontPadding(false);
            card.addView(title, new LinearLayout.LayoutParams(-1, -2));

            TextView subtitle = new TextView(this);
            subtitle.setText("لطفاً کمی صبر کنید...");
            subtitle.setTextColor(0xFFB8B8BE);
            subtitle.setTextSize(13);
            subtitle.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
            subParams.topMargin = dp(9);
            subParams.bottomMargin = dp(22);
            card.addView(subtitle, subParams);

            FrameLayout track = new FrameLayout(this);
            GradientDrawable trackBg = new GradientDrawable();
            trackBg.setColor(0xFF38383E);
            trackBg.setCornerRadius(dp(4));
            track.setBackground(trackBg);
            track.setClipToOutline(true);
            LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(
                    (int)(getResources().getDisplayMetrics().widthPixels * 0.62f), dp(5));
            card.addView(track, trackParams);

            View progress = new View(this);
            GradientDrawable progressBg = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0xFFFF1744, 0xFFFF435F});
            progressBg.setCornerRadius(dp(4));
            progress.setBackground(progressBg);
            FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(dp(70), -1, Gravity.LEFT);
            track.addView(progress, progressParams);
            progress.post(() -> {
                if (returnLoadingView != overlay) return;
                android.animation.ObjectAnimator animator = android.animation.ObjectAnimator.ofFloat(
                        progress, "translationX", -dp(75), track.getWidth() + dp(5));
                animator.setDuration(1050);
                animator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                animator.start();
                progress.setTag(animator);
            });

            FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                    (int)(getResources().getDisplayMetrics().widthPixels * 0.82f),
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
            overlay.addView(card, cardParams);
            returnLoadingView = overlay;
            root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
            overlay.setAlpha(0f);
            overlay.animate().alpha(1f).setDuration(220).start();
            card.setScaleX(0.98f);
            card.setScaleY(0.98f);
            card.animate().scaleX(1f).scaleY(1f).setDuration(220).start();
        });
    }

    private void hideReturnLoading() {
        runOnUiThread(() -> {
            if (returnLoadingView == null) return;
            View old = returnLoadingView;
            returnLoadingView = null;
            // Stop the subtle progress animation before removing the overlay.
            if (old instanceof ViewGroup) {
                ViewGroup overlay = (ViewGroup) old;
                if (overlay.getChildCount() > 0 && overlay.getChildAt(0) instanceof ViewGroup) {
                    ViewGroup card = (ViewGroup) overlay.getChildAt(0);
                    for (int i = 0; i < card.getChildCount(); i++) {
                        View child = card.getChildAt(i);
                        if (child instanceof ViewGroup) {
                            ViewGroup group = (ViewGroup) child;
                            for (int j = 0; j < group.getChildCount(); j++) {
                                Object tag = group.getChildAt(j).getTag();
                                if (tag instanceof android.animation.Animator) ((android.animation.Animator) tag).cancel();
                            }
                        }
                    }
                }
            }
            old.animate().alpha(0f).setDuration(180).withEndAction(() -> {
                if (old.getParent() == root) root.removeView(old);
            }).start();
        });
    }

    private void showLoading() {
        runOnUiThread(() -> {
            if (offlineView != null || loadingView != null) return;

            FrameLayout splash = new FrameLayout(this);
            splash.setBackgroundColor(Color.rgb(5, 4, 7));

            // Full-screen user supplied cinematic artwork.
            ImageView backdrop = new ImageView(this);
            int splashId = getResources().getIdentifier("palfinflix_splash", "drawable", getPackageName());
            if (splashId != 0) backdrop.setImageResource(splashId);
            backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
            splash.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));

            // Dark tint keeps the loading message and bar readable.
            View shade = new View(this);
            shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x33000000, 0x55000000, 0xCC000000, 0xEE000000}));
            splash.addView(shade, new FrameLayout.LayoutParams(-1, -1));

            LinearLayout bottom = new LinearLayout(this);
            bottom.setOrientation(LinearLayout.VERTICAL);
            bottom.setGravity(Gravity.CENTER);
            bottom.setPadding(34, 18, 34, 44);
            FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(
                    -1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            splash.addView(bottom, bottomParams);

            TextView title = new TextView(this);
            title.setText("پالفین‌فلیکس");
            title.setTextColor(Color.WHITE);
            title.setTextSize(25);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            bottom.addView(title, new LinearLayout.LayoutParams(-1, -2));

            TextView caption = new TextView(this);
            caption.setText("در حال آماده‌سازی دنیای فیلم و سریال...");
            caption.setTextColor(0xFFE5E5E5);
            caption.setTextSize(13);
            caption.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams captionParams = new LinearLayout.LayoutParams(-1, -2);
            captionParams.topMargin = 8;
            captionParams.bottomMargin = 22;
            bottom.addView(caption, captionParams);

            // Slim cinematic track with a glowing red segment that travels across it.
            FrameLayout track = new FrameLayout(this);
            GradientDrawable trackBg = new GradientDrawable();
            trackBg.setColor(0x66FFFFFF);
            trackBg.setCornerRadius(dp(5));
            track.setBackground(trackBg);
            track.setClipToOutline(true);
            LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(dp(250), dp(5));
            bottom.addView(track, trackParams);

            View glow = new View(this);
            GradientDrawable glowBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00FF1744, 0xFFFF1744, 0xFFFF6B81, 0xFFFF1744, 0x00FF1744});
            glowBg.setCornerRadius(dp(5));
            glow.setBackground(glowBg);
            FrameLayout.LayoutParams glowParams = new FrameLayout.LayoutParams(dp(95), -1, Gravity.LEFT);
            track.addView(glow, glowParams);
            glow.post(() -> {
                if (loadingView != splash) return;
                android.animation.ObjectAnimator animator = android.animation.ObjectAnimator.ofFloat(
                        glow, "translationX", -dp(100), track.getWidth() + dp(10));
                animator.setDuration(1150);
                animator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                animator.start();
                glow.setTag(animator);
            });

            TextView status = new TextView(this);
            status.setText("PALFINFLIX  •  LOADING");
            status.setTextColor(0xFFBBBBBB);
            status.setTextSize(10);
            status.setLetterSpacing(0.12f);
            status.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
            statusParams.topMargin = 13;
            bottom.addView(status, statusParams);

            loadingView = splash;
            root.addView(loadingView, new FrameLayout.LayoutParams(-1, -1));
            splash.setAlpha(0f);
            splash.animate().alpha(1f).setDuration(220).start();
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideLoading() {
        runOnUiThread(() -> {
            if (loadingView == null) return;
            View old = loadingView; loadingView = null;
            old.animate().alpha(0f).setDuration(220).withEndAction(() -> root.removeView(old)).start();
        });
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm) {
        showNativeMessage(message, jsResult, promptResult, confirm, "");
    }

    private void showNativeMessage(String message, android.webkit.JsResult jsResult,
                                   android.webkit.JsPromptResult promptResult, boolean confirm, String defaultValue) {
        runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, android.app.AlertDialog.THEME_DEVICE_DEFAULT_DARK);
            builder.setTitle("پالفین‌فلیکس");
            builder.setMessage(message == null ? "" : message);
            if (promptResult != null) {
                EditText input = new EditText(this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY);
                builder.setView(input);
                builder.setPositiveButton("تأیید", (d,w) -> promptResult.confirm(input.getText().toString()));
                builder.setNegativeButton("لغو", (d,w) -> promptResult.cancel());
                builder.setOnCancelListener(d -> promptResult.cancel());
            } else if (confirm) {
                builder.setPositiveButton("تأیید", (d,w) -> jsResult.confirm());
                builder.setNegativeButton("لغو", (d,w) -> jsResult.cancel());
                builder.setOnCancelListener(d -> jsResult.cancel());
            } else {
                builder.setPositiveButton("متوجه شدم", (d,w) -> jsResult.confirm());
                builder.setOnCancelListener(d -> jsResult.confirm());
            }
            try { builder.create().show(); }
            catch (Exception e) { if (jsResult != null) jsResult.cancel(); if (promptResult != null) promptResult.cancel(); }
        });
    }

    private void checkForUpdates() {
        if (!hasInternet() || updateDismissedThisSession || isFinishing()) return;
        updateExecutor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(UPDATE_API);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(7000);
                connection.setUseCaches(false);
                connection.setRequestProperty("Accept", "application/json");
                int status = connection.getResponseCode();
                if (status < 200 || status >= 300) return;
                StringBuilder body = new StringBuilder();
                try (InputStream in = new BufferedInputStream(connection.getInputStream())) {
                    byte[] buffer = new byte[2048];
                    int count;
                    while ((count = in.read(buffer)) != -1) body.append(new String(buffer, 0, count, java.nio.charset.StandardCharsets.UTF_8));
                }
                JSONObject json = new JSONObject(body.toString());
                int latestCode = json.optInt("version_code", 0);
                String latestVersion = json.optString("latest_version", "");
                String apkUrl = json.optString("apk_url", "");
                String message = json.optString("message", "نسخه جدید پالفین‌فلیکس آماده است.");
                boolean force = json.optBoolean("force_update", false);
                if (latestCode <= 0 || latestVersion.trim().isEmpty() || !apkUrl.startsWith("https://")) return;
                PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
                int currentCode = info.versionCode;
                if (latestCode > currentCode) {
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed() && !updateDismissedThisSession) {
                            showUpdateDialog(latestVersion, latestCode, apkUrl, message, force);
                        }
                    });
                }
            } catch (Exception ignored) {
                // Update checks are optional: a server or network error must not block app startup.
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void showUpdateDialog(String version, int versionCode, String apkUrl, String message, boolean force) {
        if (updateDialog != null && updateDialog.isShowing()) return;
        Dialog dialog = new Dialog(this);
        updateDialog = dialog;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(24), dp(22), dp(20));
        card.setBackground(rounded(0xFF17171B, 24));

        TextView brand = new TextView(this);
        brand.setText("PALFINFLIX");
        brand.setTextColor(0xFFFF1744);
        brand.setTextSize(13);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setLetterSpacing(0.10f);
        brand.setGravity(Gravity.CENTER);
        card.addView(brand, new LinearLayout.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("نسخه جدید منتشر شد!");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(12);
        card.addView(title, titleParams);

        TextView description = new TextView(this);
        description.setText(message + "\nنسخه " + version);
        description.setTextColor(0xFFD0D0D5);
        description.setTextSize(14);
        description.setGravity(Gravity.CENTER);
        description.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(-1, -2);
        descParams.topMargin = dp(10);
        descParams.bottomMargin = dp(20);
        card.addView(description, descParams);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setProgressTintList(ColorStateList.valueOf(0xFFFF1744));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF39393F));
        progress.setVisibility(View.GONE);
        card.addView(progress, new LinearLayout.LayoutParams(-1, dp(7)));

        TextView progressText = new TextView(this);
        progressText.setText("آماده برای به‌روزرسانی");
        progressText.setTextColor(0xFFBDBDC5);
        progressText.setTextSize(12);
        progressText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams progressTextParams = new LinearLayout.LayoutParams(-1, -2);
        progressTextParams.topMargin = dp(8);
        progressTextParams.bottomMargin = dp(16);
        card.addView(progressText, progressTextParams);

        Button update = new Button(this);
        update.setText("به‌روزرسانی");
        update.setTextColor(Color.WHITE);
        update.setAllCaps(false);
        update.setTextSize(15);
        update.setBackground(rounded(0xFFFF1744, 14));
        card.addView(update, new LinearLayout.LayoutParams(-1, dp(48)));

        Button later = new Button(this);
        later.setText("برای بعد");
        later.setTextColor(0xFFE6E6E8);
        later.setAllCaps(false);
        later.setTextSize(14);
        later.setBackground(rounded(0xFF303036, 14));
        LinearLayout.LayoutParams laterParams = new LinearLayout.LayoutParams(-1, dp(44));
        laterParams.topMargin = dp(8);
        card.addView(later, laterParams);

        update.setOnClickListener(v -> {
            update.setEnabled(false);
            later.setEnabled(false);
            progress.setVisibility(View.VISIBLE);
            progressText.setText("در حال آماده‌سازی دانلود...");
            startApkDownload(apkUrl, version, progress, progressText, update, later, force);
        });
        later.setOnClickListener(v -> {
            if (force) {
                Toast.makeText(this, "برای ادامه، نصب نسخه جدید لازم است.", Toast.LENGTH_LONG).show();
                return;
            }
            updateDismissedThisSession = true;
            dialog.dismiss();
        });

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(card);
        dialog.setCancelable(!force);
        dialog.setCanceledOnTouchOutside(!force);
        dialog.setOnDismissListener(d -> { if (updateDialog == dialog) updateDialog = null; });
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.72f;
            window.setAttributes(lp);
        }
        if (force) later.setVisibility(View.GONE);
    }

    private void startApkDownload(String apkUrl, String version, ProgressBar progress,
                                  TextView progressText, Button update, Button later, boolean force) {
        try {
            Uri uri = Uri.parse(apkUrl);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
                throw new IllegalArgumentException("Invalid APK URL");
            }
            String filename = uri.getLastPathSegment();
            if (filename == null || !filename.toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                filename = "PalfinFlix-" + version + ".apk";
            }
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle("به‌روزرسانی پالفین‌فلیکس");
            request.setDescription("در حال دانلود نسخه " + version);
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, filename);
            activeDownloadId = manager.enqueue(request);
            downloadProgressRunning = true;
            pollDownloadProgress(manager, progress, progressText, update, later, force, version);
        } catch (Exception e) {
            update.setEnabled(true);
            later.setEnabled(true);
            progressText.setText("شروع دانلود ممکن نشد. دوباره تلاش کنید.");
            Toast.makeText(this, "دانلود به‌روزرسانی آغاز نشد.", Toast.LENGTH_LONG).show();
        }
    }

    private void pollDownloadProgress(DownloadManager manager, ProgressBar progress, TextView progressText,
                                      Button update, Button later, boolean force, String version) {
        updateHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!downloadProgressRunning || isFinishing() || isDestroyed()) return;
                DownloadManager.Query query = new DownloadManager.Query().setFilterById(activeDownloadId);
                try (Cursor cursor = manager.query(query)) {
                    if (cursor == null || !cursor.moveToFirst()) {
                        finishDownloadUi(progressText, update, later, "وضعیت دانلود مشخص نشد.");
                        return;
                    }
                    int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    if (total > 0) {
                        int percent = (int) Math.min(100, (downloaded * 100L) / total);
                        progress.setProgress(percent);
                        progressText.setText("در حال دانلود نسخه " + version + " — " + percent + "%");
                    } else {
                        progressText.setText("در حال دانلود نسخه " + version + "...");
                    }
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        downloadProgressRunning = false;
                        progress.setProgress(100);
                        progressText.setText("دانلود کامل شد؛ در حال باز کردن نصب‌کننده...");
                        Uri apkUri = manager.getUriForDownloadedFile(activeDownloadId);
                        if (apkUri == null) {
                            finishDownloadUi(progressText, update, later, "فایل دانلود شد اما باز کردن آن ممکن نشد.");
                            return;
                        }
                        try {
                            Intent install = new Intent(Intent.ACTION_VIEW);
                            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
                            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(install);
                        } catch (Exception e) {
                            finishDownloadUi(progressText, update, later, "نصب‌کننده اندروید باز نشد. فایل در دانلودهای برنامه ذخیره شده است.");
                        }
                        return;
                    }
                    if (status == DownloadManager.STATUS_FAILED) {
                        downloadProgressRunning = false;
                        int reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                        finishDownloadUi(progressText, update, later, "دانلود ناموفق بود (" + reason + "). اینترنت را بررسی و دوباره تلاش کنید.");
                        return;
                    }
                    updateHandler.postDelayed(this, 400);
                } catch (Exception e) {
                    finishDownloadUi(progressText, update, later, "بررسی وضعیت دانلود با خطا روبه‌رو شد.");
                }
            }
        }, 150);
    }

    private void finishDownloadUi(TextView progressText, Button update, Button later, String message) {
        downloadProgressRunning = false;
        progressText.setText(message);
        update.setEnabled(true);
        later.setEnabled(true);
    }

    private boolean hasInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return true; }
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private void showOffline() {
        runOnUiThread(() -> {
            pageFailed = true;
            // Crucial privacy fix: never leave the built-in WebView error document visible,
            // because it can expose the start URL and technical error details to copy/select.
            if (web != null) web.setVisibility(View.INVISIBLE);
            hideLoading();
            if (offlineView != null) root.removeView(offlineView);
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            page.setGravity(Gravity.CENTER);
            page.setBackgroundColor(Color.rgb(8,8,8));
            // Scale the offline composition for short/tall screens instead of relying on fixed 190dp art.
            float density = getResources().getDisplayMetrics().density;
            int screenHeightDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
            int iconSize = Math.max(112, Math.min(166, Math.round(screenHeightDp * 0.19f)));
            int sidePadding = Math.max(20, Math.min(32, Math.round(screenHeightDp * 0.035f)));
            int brandGap = Math.max(18, Math.min(34, Math.round(screenHeightDp * 0.04f)));
            int iconGap = Math.max(16, Math.min(24, Math.round(screenHeightDp * 0.027f)));
            int descGap = Math.max(16, Math.min(24, Math.round(screenHeightDp * 0.027f)));
            page.setPadding(sidePadding, 12, sidePadding, 12);

            TextView brand = new TextView(this);
            brand.setText("PALFINFLIX"); brand.setTextColor(Color.rgb(229,9,20));
            brand.setTextSize(27); brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            brand.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.bottomMargin=brandGap;
            page.addView(brand,bp);

            FrameLayout iconBox = new FrameLayout(this);
            iconBox.setBackground(rounded(Color.rgb(28,28,28), 100));
            LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(iconSize,iconSize); ibp.bottomMargin=iconGap;
            page.addView(iconBox,ibp);
            TextView wifi = new TextView(this);
            wifi.setText("⌁"); wifi.setTextColor(Color.rgb(229,9,20)); wifi.setTextSize(Math.max(52, Math.min(68, iconSize * 0.36f)));
            wifi.setGravity(Gravity.CENTER);
            iconBox.addView(wifi,new FrameLayout.LayoutParams(-1,-1));
            AlphaAnimation pulse = new AlphaAnimation(0.35f,1f); pulse.setDuration(900); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE); wifi.startAnimation(pulse);

            TextView title = new TextView(this);
            title.setText("اتصال برقرار نشد"); title.setTextColor(Color.WHITE); title.setTextSize(21);
            title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
            page.addView(title);
            TextView desc = new TextView(this);
            desc.setText("اینترنت خود را چک کنید"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(16);
            desc.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=8; dp.bottomMargin=descGap;
            page.addView(desc,dp);
            TextView retry = new TextView(this);
            retry.setText("تلاش مجدد"); retry.setTextColor(Color.WHITE); retry.setTextSize(16); retry.setGravity(Gravity.CENTER);
            retry.setPadding(42,16,42,16); retry.setBackground(rounded(Color.rgb(229,9,20),50));
            retry.setOnClickListener(v -> {
                if (hasInternet()) {
                    if (offlineView != null) { root.removeView(offlineView); offlineView = null; }
                    // Show the cinematic loading screen before retrying so the WebView's
                    // temporary blank/black frame is never exposed to the user.
                    pageFailed = false;
                    web.setVisibility(View.VISIBLE);
                    showLoading();
                    web.loadUrl(HOME);
                } else {
                    wifi.clearAnimation();
                    wifi.startAnimation(pulse);
                }
            });
            page.addView(retry);
            offlineView = page;
            root.addView(offlineView,new FrameLayout.LayoutParams(-1,-1));
        });
    }

    @Override public void onBackPressed() {
        if (offlineView != null) {
            if (hasInternet()) {
                root.removeView(offlineView);
                offlineView = null;
                pageFailed = false;
                web.setVisibility(View.VISIBLE);
                showLoading();
                web.loadUrl(HOME);
            } else super.onBackPressed();
        }
        else if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
