کلید امضای دائمی پالفین‌فلیکس

فایل keystore: palfinflix-release.jks
Alias: palfinflix-release
Store password: s7-AvP6$LaNGE-QMfOfz#o7oF=6C
Key password: s7-AvP6$LaNGE-QMfOfz#o7oF=6C

این فایل و keystore را در دو جای امن نگهداری کنید. گم شدن keystore یا رمزها ممکن است به معنی عدم امکان به‌روزرسانی مستقیم نسخه‌های امضاشده با این کلید باشد.
