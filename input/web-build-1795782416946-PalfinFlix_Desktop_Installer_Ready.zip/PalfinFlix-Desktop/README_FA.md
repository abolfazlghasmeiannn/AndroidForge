# PalfinFlix Desktop

نسخه دسکتاپ مستقل پالفین‌فلیکس با Electron؛ پنجره برنامه در شروع وسط صفحه و غیرتمام‌صفحه باز می‌شود و صفحه دسکتاپ سایت را نمایش می‌دهد.

**نشانی داخل برنامه:** https://palfinflix.ir/palfinapk/palfintvvin.php

## خروجی قابل نصب
- Windows: فایل نصبی `.exe` با امکان انتخاب مسیر نصب و ساخت میانبر روی Desktop و Start Menu.
- macOS: فایل `.dmg` و آرشیو `.zip` (برای نصب عمومی و اجرای بدون هشدار امنیتی، امضای توسعه‌دهنده و notarization اپل جداگانه لازم است).
- Linux: فایل‌های `.AppImage` و `.deb`.

## ساخت با GitHub Actions
1. ZIP را استخراج کنید.
2. **تمام محتویات داخل پوشه `PalfinFlix-Desktop`** را مستقیماً در ریشه Repository گیت‌هاب قرار دهید؛ نباید یک پوشه اضافی بین ریشه مخزن و `package.json` یا `.github` باشد.
3. فایل Workflow باید دقیقاً در مسیر `.github/workflows/build-desktop.yml` باشد و `package.json` باید کنار پوشه‌های `src` و `.github` در ریشه مخزن باشد.
4. Commit و Push روی شاخه `main` کنید.
5. در GitHub به Actions بروید و `Build Desktop (Windows + macOS + Linux)` را انتخاب کنید؛ سپس `Run workflow` بزنید.
6. پس از موفقیت، فایل‌های نصب را از بخش Artifacts همان اجرای Workflow دانلود کنید.

این Workflow برای Electron است و عمداً هیچ دستور Flutter مانند `flutter pub get` ندارد. اگر در GitHub همچنان دستور Flutter اجرا شد، یعنی Workflow قدیمی دیگری در مخزن اجرا شده یا فایل جدید در مسیر درست جایگزین نشده است.

## ساخت محلی (اختیاری)
Node.js نسخه 22 را نصب کنید و در پوشه‌ای که `package.json` قرار دارد اجرا کنید:

```bash
npm install
npm start
```

برای ساخت نصاب‌ها:

```bash
npm run dist:win
npm run dist:mac
npm run dist:linux
```

ساخت خروجی macOS باید روی runner یا دستگاه macOS انجام شود. برای انتشار رسمی macOS، امضای کد و notarization نیازمند حساب توسعه‌دهنده اپل است.

## نکته درباره AndroidForge
این پروژه دسکتاپ Electron است و برای AndroidForge/ساخت APK اندروید نیست. برای ساخت فایل نصبی کامپیوتر از GitHub Actions همین پروژه استفاده کنید.

## وضعیت بررسی
ساخت واقعی EXE/DMG/AppImage در این محیط اجرا نشده است؛ Workflow و فایل‌های پروژه تنظیم شده‌اند، اما موفقیت نهایی باید در اجرای GitHub Actions تأیید شود. اگر خطا رخ داد، گزارش مرحله قرمز را ارسال کنید.
